#!/bin/bash
cd /tmp/;nohup /usr/sbin/safe_asterisk&
