#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
#my $uid=0;
my $who=$ses->param("login_name");

#my $a=$cgi->param("filter");

db_query_exec("update trunks_trunk set paused=0,auto_pause_2=0 ,auto_pause_3=0,auto_pause_1=0  ");

db_commit();

#start block
print html_redirect("Trunks.pl");
