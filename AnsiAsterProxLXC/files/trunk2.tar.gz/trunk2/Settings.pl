#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who='User '.$ses->param("login_name");


#start block
my $mname="";
print html_header;
my $broken="";
my $pauses='';

my %vars= (  top => util_top('Settings',$who).util_top_menu('Settings'),tab=>html_table(db_query("select 
   concat('<a href=\"settings_edit.pl?id=',id,'\" >E</a>') as action,
	id,akey,value,description
  from options order by id" )
 )
);

print util_template("templates/Settings.tmpl",\%vars);
