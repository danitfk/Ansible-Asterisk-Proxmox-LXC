#!/bin/bash
counts=`ps ax|grep check_mysql.sh|grep -v grep |nl|tail -n 1 |cut -b 1-6`
echo $counts
if test $counts -ge 3
then
exit;
fi;

mysql="/usr/bin/mysql asterisk -h mysql -u trunk2 -pmtest -s"
while true;
do
if test "`echo "select 1"|$mysql`" == ""
then
 echo "no connenct";
 /etc/init.d/asterisk stop
 res=1
 while test "$res" == "1"
 do
   sleep 10
   if test "`echo "select 1"|$mysql`" == ""
   then
     echo "still no connect"
   else
	echo "connection ok"
	killall server.pl
	/etc/init.d/asterisk start
	res=0
   fi;
 done;
fi;
if test "`tail -n 10 /var/log/asterisk/messages |grep ERROR|grep ' cdr_addon_mysql'|tail -n 1`" == ""
then
 echo all is ok
else 
 echo mysql errors
 /usr/sbin/asterisk -rx "restart now"
 killall server.pl
 echo "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrestart\n\n\n\n">>/var/log/asterisk/messages

fi;
sleep 10
echo ok
done;
