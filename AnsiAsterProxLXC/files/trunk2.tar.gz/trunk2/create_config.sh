#!/bin/bash
#rule="outrt-001-DONOTMOVE"
REDIAL_DELAY=15
port=`cat /var/www/html/trunk2/port.opt`
PATH=/usr/kerberos/sbin:/usr/kerberos/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
export PATH
autopeer="qualify=no
;disallow=all
allow=g729
allow=g723
allow=ulaw
allow=alaw
";

cd /var/www/html/trunk2/
/var/www/html/trunk2/install.pl
prefix_replace=" replace(ext_prefix,'\$','') ";
mysql="/usr/bin/mysql asterisk -u trunk2 --password=mtest -s -h mysql"

echo "[trunks2-hangup-handler]
 
exten => s,1,NoOp()
same => n,DeadAGI(agi://127.0.0.1:$port/mark_hangup)">/etc/asterisk/extensions_trunks.conf
echo '
same => n,Set(HANGUPCAUSE_STRING=${HANGUPCAUSE_KEYS()})
 
same => n,Set(MASTER_CHANNEL(SIPcause)=${HANGUPCAUSE(${HANGUPCAUSE_STRING},tech)})
 
same => n,Return()'>>/etc/asterisk/extensions_trunks.conf

echo "[trunks2_answer]
exten => s,1,Noop(answer)
exten => s,n,DeadAGI(agi://127.0.0.1:$port/mark_answer)
exten => s,n,Return(CONTINUE)

[reverse_calling]
exten => _.,1,DeadAGI(agi://127.0.0.1:$port/reverse_calling)
exten => _.,2,Hangup
exten => h,1,Hangup
exten => T,1,Hangup
exten => t,1,Hangup
exten => i,1,HAngup
 ">>/etc/asterisk/extensions_trunks.conf

echo "[trunks2]">>/etc/asterisk/extensions_trunks.conf

echo "; set outbound hadler 
exten => sh,1,Set(CHANNEL(hangup_handler_push)=trunks2-hangup-handler,s,1)
exten => sh,n,Return()

">>/etc/asterisk/extensions_trunks.conf

for i in `echo "select distinct $prefix_replace from trunks_group_rules where allow=1"|$mysql`
do
echo "exten => _$i.,1,Noop
exten => _$i.,n,Set(CDR(userfield)=\${SIPCHANINFO(recvip)}\${IAXPEER(CURRENTCHANNEL)});for ip mark
exten => _$i.,n,DeadAGI(agi://127.0.0.1:$port/fastagi_handler?dst=\${EXTEN})" >>/etc/asterisk/extensions_trunks.conf
echo "exten => _$i.,n,Congestion(3)">>/etc/asterisk/extensions_trunks.conf
done;

for i in `echo "select distinct replace(prefix,'\$','') from trunks_agent where not paused"|$mysql`
do
echo "exten => _$i.,1,Noop
exten => _$i.,n,Set(CDR(userfield)=\${SIPCHANINFO(recvip)}\${IAXPEER(CURRENTCHANNEL)});for ip mark
exten => _$i.,n,DeadAGI(agi://127.0.0.1:$port/fastagi_handler?dst=\${EXTEN})" >>/etc/asterisk/extensions_trunks.conf
echo "exten => _$i.,n,Congestion(3)">>/etc/asterisk/extensions_trunks.conf
done;
echo "[trunks_wait]
exten => s,1,Wait($REDIAL_DELAY)
exten => s,2,Busy
">>/etc/asterisk/extensions_trunks.conf
/usr/sbin/asterisk -rx "extensions reload " >/dev/null

echo "" >/etc/asterisk/iax_trunks.conf
echo "" >/etc/asterisk/sip_trunks.conf
#######################################################
################### templates
######################################################
for i in `echo "select concat(id,':',name) from trunks_template where trunk_type='SIP'"|$mysql`
do
id=`echo "$i"|cut -d: -f 1`
name=`echo "$i"|cut -d: -f 2|sed -e 's/\s//g' `
echo ";id=$id;
[$name](!)">>/etc/asterisk/sip_trunks.conf
echo "select value from trunks_template where id=$id"|$mysql |sed -e 's/\\n/\n/g' >>/etc/asterisk/sip_trunks.conf
echo ";">>/etc/asterisk/sip_trunks.conf
done;


for i in `echo "select concat(id,':',name) from trunks_template where trunk_type='IAX2'"|$mysql`
do
id=`echo "$i"|cut -d: -f 1`
name=`echo "$i"|cut -d: -f 2|sed -e 's/\s//g' `
echo ";id=$id;
[$name](!)">>/etc/asterisk/iax_trunks.conf
echo "select value from trunks_template where id=$id"|$mysql|sed -e 's/\\n/\n/g' >>/etc/asterisk/iax_trunks.conf
echo ";">>/etc/asterisk/iax_trunks.conf
done;


################################################
#################### trunks
##########################################
for i in `echo "select concat(a.id,':',a.name,':',b.name,':',secret,':',ip,':',case when add_ip is null then '' else add_ip end) from trunks_trunk as a  left join trunks_template as b on b.id=a.template_id where a.trunk_type='SIP'"|$mysql`
do
id=`echo "$i"|cut -d: -f 1`
name=`echo "$i"|cut -d: -f 2|sed -e 's/\s//g' `
tmpl=`echo "$i"|cut -d: -f 3`
secret=`echo "$i"|cut -d: -f 4`
if test "1$secret" != "1"
then
 secret="secret=$secret"
fi;
ip=`echo "$i"|cut -d: -f 5`
ips=`echo "$i"|cut -d: -f 6|sed -e 's/[\,\;]/ /g' -e 's/\s{2-5}/ /g' |sed -e 's/^\s//' `
echo ";id=$id;
[$name]($tmpl)
host=$ip
;username=$name
$secret
;">>/etc/asterisk/sip_trunks.conf


if test "1$ips" != "1"
then
## echo IP: $ips
 p=0
 for ip in $ips
 do
	 echo ";id=$id;
[${name}__$p]($tmpl)
host=$ip
;username=$name
$secret
;">>/etc/asterisk/sip_trunks.conf
	 p=`expr $p + 1 `
 
 done
fi;

done;

for i in `echo "select concat(a.id,':',a.name,':',b.name,':',secret,':',ip,':',case when add_ip is null then '' else add_ip end) from trunks_trunk as a  left join trunks_template as b on b.id=a.template_id where a.trunk_type='IAX2'"|$mysql`
do
id=`echo "$i"|cut -d: -f 1`
name=`echo "$i"|cut -d: -f 2|sed -e 's/\s//g' `
tmpl=`echo "$i"|cut -d: -f 3`
secret=`echo "$i"|cut -d: -f 4`
ip=`echo "$i"|cut -d: -f 5`
ips=`echo "$i"|cut -d: -f 6|sed -e 's/[\,\;]/ /g' -e 's/\s{2-5}/ /g' |sed -e 's/^\s//' `

echo ";id=$id;
[$name]($tmpl)
host=$ip
secret=$secret
username=$name
;">>/etc/asterisk/iax_trunks.conf

if test "1$ips" != "1"
then
 p=0
# echo IPS: $ips
 for ip in $ips
 do
         echo ";id=$id;
[${name}__$p]($tmpl)
host=$ip
username=$name
secret=$secret
;">>/etc/asterisk/iax_trunks.conf
         p=`expr $p + 1 `

 done
fi;


done;










################################################
####                      agents autopeer
####################################
for i in sip iax
do
  echo "[peerdef](!)
host=127.0.0.1
type=friend
context=trunks2
directmedia=no
$autopeer
  ">>/etc/asterisk/${i}_trunks.conf
if test "$i" = "sip"
then
echo "insecure=port,invite">>/etc/asterisk/${i}_trunks.conf
fi;
  for id in `echo "select id from trunks_agent where autopeer='$i'"|$mysql`	
  do

	name=`echo "select name from trunks_agent where id=$id"|$mysql |sed -e "s/\s//g"`
	n=1;
	for ip in `echo "select INET_NTOA(ip) from trunks_agent_ip where agent_id=$id"|$mysql`
	do
		echo "[$name$n](peerdef)
host=$ip
		">>/etc/asterisk/${i}_trunks.conf
		n=$[ $n + 1 ]
	done;
  done;

done;





#####################chan datacrd/dongle

echo >/etc/asterisk/dongle_trunks.conf

for i in `echo "select concat(a.id,':',a.name,':',b.id,':',secret,':',ip,':',case when add_ip is null then '' else add_ip end) from trunks_trunk as a  left join trunks_template as b on b.id=a.template_id where a.trunk_type='Datacard' or a.trunk_type='Dongle' "|$mysql `
do

id=`echo "$i"|cut -d: -f 1`
name=`echo "$i"|cut -d: -f 2|sed -e "s/\s//g"`
tmpl=`echo "$i"|cut -d: -f 3` #template id
secret=`echo "$i"|cut -d: -f 4`
ip=`echo "$i"|cut -d: -f 5`
echo "[$name];autogenerated id=$id tempalte=$tmpl">>/etc/asterisk/dongle_trunks.conf
echo "select value from trunks_template where id=$tmpl"|$mysql|sed -e 's/\\n/\n/g'  >>/etc/asterisk/dongle_trunks.conf
echo "imei=$ip">>/etc/asterisk/dongle_trunks.conf

done;









for i in sip iax extensions dongle
do
a=`cat /etc/asterisk/$i.conf|grep ${i}_trunks.conf`
if  test "1$a" == "1"
then
 echo "installing into /etc/asterisk/$i.conf"
 echo "#include ${i}_trunks.conf">>/etc/asterisk/$i.conf
fi;
done;

a=`cat /etc/rc.local|grep safe_server.sh `
if test "1$a" == "1"
then
echo "installing into rc.local"
echo "
/usr/sbin/safe_asterisk&
cd /var/www/html/trunk2/;nohup ./safe_server.sh &
">>/etc/rc.local
fi;


/usr/sbin/asterisk -rx "sip reload"
/usr/sbin/asterisk -rx "dialplan reload"
/usr/sbin/asterisk -rx "iax2 reload"


