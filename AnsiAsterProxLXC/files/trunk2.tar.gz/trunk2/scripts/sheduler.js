var project_id;

function sheduler_init(id){
 project_id=id;
 $('#sheduler').hide();
 $.getJSON(
 'sheduler_json.pl',
 {
  action: "get",
  id: id
 },
  sheduler_get_ok
 )
 return false;
}

function sheduler_get_ok(obj){
  lastobj=obj;
 for(var i=0;i<7;i++){
  for (var j= 0;j<=23;j++){
   var r=obj[i*25 + j];
   $("#"+i+"_"+j).removeClass().addClass('c_'+r);
  }
}
 $('#sheduler').slideDown(500);
}

function sheduler_click(obj){
 lastobj=obj;
 var a=parseInt(obj.className.substr(2));
 a=(a+1) % 3;
 obj.className='c_'+a;
}

function sheduler_save(){
 var a={
  action: "set",
  id: project_id
 };
 for(var i=0;i<7;i++){
  for (var j= 0;j<=23;j++){
   a[''+i+'_'+j]=$("#"+i+"_"+j).attr('className').substr(2);
  }
 }

  $.getJSON(
 'sheduler_json.pl',
 a
 ,
  sheduler_save_ok
 )
 return false;
}

function sheduler_save_ok(obj){
  lastobj=obj;
 alert('saved');
}

