$('#stop').find("option,[@value="+stop+"]").attr("selected",'selected');
var tab;
var user;
var uid;
var lastc;
var last_tr_vm="<TR onMouseOver='m_clear();' onClick='m_show_new()'><TD class='top_header' colspan='4' class='ta_c'><b>Click to Add New Box</b></TD></tr>";
var edit="<a href='#'  onclick='m_show_edit()'><img src='img/edit.gif' hint='Edit'></a><a href='#'  onclick='m_delete()'>"+
"<img src='img/delete.gif'   hint='Delete'></a>";
var tr_vm="<TR onMouseOver=\"m_in(this)\"  ><TD width=10% ><div class='head'>"+edit+"<div></TD><TD  class='ta_c'>";
function showTable(obj)
{ 
 lastobj=obj;
 tab=lastobj.tab;
for ( b  in tab) {
 var str=tr_vm;
 str+=tab[b][0]+"</TD><TD>";
 str+="<div>"+tab[b][1]+"</div></td><TD><div>"+tab[b][2]+"</div><div class='hidden'>"+tab[b][3]+"</div>";
 $("#tboxes").append(str+"</TD></tr>");
 $("#tboxes").find("div.head").hide();
 $("#tboxes").find("div.hidden").hide();
};
 $("#tboxes").append(last_tr_vm);
 tab=obj;
}

function m_in(tr){
 m_clear();
 tr.className='mtr_1';
 $(tr).find('div.head').show();
 prevtr=tr;
}
function m_clear(){
 if (typeof(prevtr) != "undefined"){
  prevtr.className='mtr_2';
  $(prevtr).find('div.head').hide();
 }
}
function m_show_new(){
 $("#dboxes").hide();
 $("#dboxes_new").slideDown(500);
 
}
function m_show_all(){
 $("#dboxes_new").hide();
 $("#dboxes_update").hide();
 $("#dboxes").slideDown(500);

}
var new_req;
function m_new(){
 var cid=$("#cid").attr('value');
 if (typeof(cid) == "undefined"){
  alert("pls enter callerid");
 }else {
 new_req={action: "new",
   cid: cid,
   rec_id: $("#new_rec").attr('value')
  };

 $.getJSON(
 'index.pl',
  new_req,
  m_new_ok
 );
 }
}
function m_new_ok(obj){
 if (obj.response == "ok"){
  
   var str=tr_vm;
  str+=$("#cid").attr('value')+"</TD><TD>";
  str+="<div></div></td><TD><div>"+obj.name+"</div></TD></tr>";
  $("#tboxes").find('tr:last').before(str);
  m_show_all();
 }else {
  alert("error create. try again later");
 }
}
var vm_del;
function m_delete(){
 vmdel=prevtr;
 var mbox=$(prevtr).find("td:nth(1)").text();
 $.getJSON(
 'index.pl',
 {
  action: "del",
  box: mbox
 },
  m_del_ok
 )
 return false;
}
function m_del_ok(obj){
 if (obj.response == "ok"){
  lastobj=obj;
  $(vmdel).hide();
  }
 else {
  alert("error delete. try again later");
 }

}

var del_n="<a href='#'  onclick='m_num_delete(this)'><img src='img/delete.gif'   hint='Delete'></a>";
function m_show_edit(){
 $("#dboxes").hide();
 vm_edit=prevtr;
 $("#dboxes_update").slideDown(500);
 $("#ucid").text($(vm_edit).find("td:nth(1)").text());
 var numb=$(vm_edit).find("td:nth(2)").text();
 aa=numb.split(' ');
 $("#dboxes_update").find("#ulast ~ tr").remove();
 for (a in aa){
 if (aa[a]!=""){
 $("#tboxes_update").append("<TR><TD class='content_td_grey'>"+ del_n+"number</td><TD class='num'>"+aa[a]+"</td></tr>");
 }
 }
 $('#rec_u').find("option,[@value="+$(vm_edit).find("div.hidden").text()+"]").attr("selected",'selected');
}
function m_add_number(){
 var a=prompt("Pls enter number");
 if(a=="") {alert('number must be not empty'); return 0;};
  $("#tboxes_update").append("<TR><TD class='content_td_grey'>"+ del_n+"number</td><TD class='num'>"+a+"</td></tr>");
}
var a_mnum;
function m_num_delete(obj){
 $(obj).addClass("to_remove");
 $("#tboxes_update").find("tr:has(a.to_remove)").remove();
}
function m_update(){
 var ucid=$(vm_edit).find("td:nth(1)").text();
 var a="";
 $("#tboxes_update").find("td.num").each(
  function(i)
  {
    a=a+' '+this.innerHTML;
  }
  );
 a=a.substring(1);
 upd_req={action: "update",
   cid: ucid,
   rec: $('#rec_u').children("[@selected]").attr("value"),
   number:  a
  };

 $.getJSON(
 'index.pl',
  upd_req,
  m_update_ok
 );
}

function m_update_ok(obj){
 if (obj.response == "ok"){
   $(vm_edit).find("td:nth(2)").find("div").text(upd_req.number);
   $(vm_edit).find("td:nth(3)").find("div:nth(0)").text(obj.name);
   $(vm_edit).find("td:nth(3)").find("div:nth(1)").text(upd_req.rec);
  m_show_all();
 }else {
  alert("error update. try again later");
 }
}

