function selectOption(mopt,ovalue){
 mopt=document.getElementById(mopt);
 if (mopt === null) return;
 mopt.value=ovalue;
 var i;var child=mopt.options;
 for( i=0;i< child.length;i++){
  if(child[i].value==ovalue) child[i].selected=true;
  else child[i].selected=false;
 }
};
function getOption(mopt){
 var i;var child=mopt.options;
 for( i=0;i< child.length;i++){
  if(child[i].selected) return child[i].value;
 }
};
function submit_plan(number) {
 var opt=document.getElementById('plan'+number);
 var rform= document.getElementById('request');
 rform.plan.value=getOption(opt);
 rform.number.value=number;
 rform.submit();
}
function m_submit(val,val2){
 var rform= document.getElementById('actions');
 if (confirm("Are u sure do "+val2+ "?")){
 rform.action=val;
 rform.submit();
 } 
}
function m_submit1(val,val2,val3,val4){
 var rform= document.getElementById('actions');
 if (confirm("Are u sure do "+val2+ "?")){
 rform.action=val;
 rform.prefix.value=val3;
 rform.filter.value=val4;
 rform.submit();
 }
}

function submit_group(){
	var rform= document.getElementById('ftrunks');
	rform.submit();
}
