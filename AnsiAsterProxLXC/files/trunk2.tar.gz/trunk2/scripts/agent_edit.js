function agent_rules_submit(){
	if($("#rt").attr("value") < 3){
		$("#forma").submit();
	}else{
	    if(confirm("Are you sure convert this to multirule?(reverse proccess not supported)")){
		$("#rt").attr("disabled","disabled");	
		agent_mrule_create();
	    }else{
		return false;
	    }
	}

}
function agent_mrule_create(){
   set_status("creating multirule");
    $.getJSON(
 'agent_mrule_json.pl',
 {      
  action: "create",
  id: $("#id").attr("value"),
 },             
  create_ok
 )      
        
}
function create_ok(obj){
	multirule_show();
}
function multirule_show(){
 $("#m_bottom").hide();
 $("#m_mbottom").show();
 $("#rt").attr("disabled","disabled");
	$.getJSON(
 'agent_mrule_json.pl',
 {
  action: "get",
  id: $("#id").attr("value"),
 },
  get_ok
 )
}
function get_ok(obj){
  $("#mrule").show();
  var action="<a href=\"agent_rule_del.pl?aid="+$("#aid").val()+"&id=";
  obj[0].forEach(function(entry) {
    $("#mrule tbody").append("<TR><TD>"+action+entry[0]+"\">D</a></TD><TD>"+entry[1]+"<TD></TR>");
  });
  $(".r3 td:nth(1)").html(obj[1]);
}
function agent_rules_save_info(){
 set_status("saving info");
 $.getJSON(
	'agent_mrule_json.pl',
 {
  action: "save_info",
  id: $("#id").attr("value"),
  name: $("#name").attr("value"),
  cost: $("#cost").attr("value"),
  max_count: $("#max_count").attr("value"),
 },
  agent_rules_save_info_ok
 )
}


function agent_rules_save_info_ok(){
  set_status("saved ok");
}



function set_status(val){
        $("#status").html(val);
	$("#status").show();
}
  

function a2g_delete(id){
 if(confirm("Are you sure delete this group?")){
	$("#a2g_action").attr("value","delete");
	$("#a2g_id").attr("value",id);
	$("#a2g_form").submit();
 }
}
function a2g_add(){
        $("#a2g_action").attr("value","add");
        $("#a2g_form").submit();
}

function check_upload(){
 if(document.getElementById("csv").value != ""){
   $("#fupload").submit();
 }
}
