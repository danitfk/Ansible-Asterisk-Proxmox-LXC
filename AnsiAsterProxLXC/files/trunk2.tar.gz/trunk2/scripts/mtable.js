addEvent(window, "load", mtables_init);

var SORT_COLUMN_INDEX;
var M_TD_COUNT;
function m_exist(params,pname){ return !(typeof params[pname]=="undefined")}
if (m_exist(m_param,'m_start_sort')) SORT_COLUMN_INDEX=m_param['m_start_sort'];
var m_class_name;

function m_form(){
 return document.getElementById(m_param['m_form']);
}
function m_next(){
var f=m_form();
 if (f.page.value*1<f.pagemax.value*1){
 f.act.value='next';
 f.submit();
 }
}
function m_prev(){
var f=m_form();
 if (f.page.value*1>0){
 f.act.value='prev';
 f.submit();
 }
}


function mtables_init() {
    // Find all tables with class sortable and make them sortable
    if (!document.getElementsByTagName) return;
    if (!m_exist(m_param,'m_class_name')) return;
    m_class_name=m_param['m_class_name'];
    tbls = document.getElementsByTagName("table");
    for (ti=0;ti<tbls.length;ti++) {
        thisTbl = tbls[ti];
        if (((' '+thisTbl.className+' ').indexOf(m_class_name) != -1) && (thisTbl.id)) {
            initTable(thisTbl.id);
	    
            ts_makeSortable(thisTbl);
        }
    }
}
function initTable(id){
 var tab=document.getElementById(id);
 var trElem, tdElem;
//add headers
 trElem = tab.insertRow(0);
 if(m_exist(m_param,'m_header_tr_class' ) ) trElem.className = m_param['m_header_tr_class'];

 for (var j = 0; j < m_param['m_headers'].length; j++){
  tdElem=trElem.insertCell(trElem.cells.length);
  tdElem.width=m_param['m_width'][j];
  tdElem.innerHTML =m_param['m_headers'][j];
  if (m_exist(m_param,'m_header_td_class' ) ) tdElem.className = m_param['m_header_td_class'];
 }
//add up
 trElem = tab.insertRow(0);
 if(m_exist(m_param,'m_header_trT_class' ) ) trElem.className = m_param['m_header_trT_class'];
  tdElem=trElem.insertCell(0)
  tdElem.colSpan=m_param['m_headers'].length;
  var a=m_param['m_top'];
  var f=m_form();
  var pm=parseInt(f.pagemax.value);
  var p=parseInt( f.page.value); 
  if (p>0 ) 
    a=a.replace (/%prev/,'<a href="#" onclick="m_prev()" class="'+m_param['m_top_link']+'">Prev</a>')
   else a=a.replace (/%prev/,'');
  if (p<pm )
    a=a.replace (/%next/,'<a href="#" onclick="m_next()" class="'+m_param['m_top_link']+'">Next</a>')
   else a=a.replace (/%next/,'');
  if (m_exist(m_param,'m_pages' )){
   a=a.replace (/%page/,p + 1);
   a=a.replace (/%pages/,pm + 1);
  }
// <a href="#" onclick="m_prev()" class="l_link">
  tdElem.innerHTML =a;
  if (m_exist(m_param,'m_header_tdT_class' ) ) tdElem.className = m_param['m_header_tdT_class'];
  ts_makeColor(tab); 
}

function ts_makeSortable(table) {
    if (table.rows && table.rows.length > 0) {
        var firstRow = table.rows[1];
    }
    if (!firstRow) return;
    
    // We have a first row: assume it's the header, and make its contents clickable links
    for (var i=0;i<firstRow.cells.length;i++) {
        var cell = firstRow.cells[i];
        var txt = ts_getInnerText(cell);
        cell.innerHTML = '<a href="#" class="'+m_class_name+'_sortheader" '+ 
        'onclick="ts_resortTable(this, '+i+');return false;">' + 
        txt+'<span class="'+m_class_name+'_sortarrow">&nbsp;&nbsp;</span></a>';
    }
  if (m_exist(m_param,'m_start_sort')&&(m_param['m_start_sort']>-1)){
    cell = firstRow.cells[m_param['m_start_sort']];
    ts_resortTable(cell.firstChild,m_param['m_start_sort']);
  }
}
function ts_makeColor(table){
 for (var i=2;i<table.rows.length-1;i++){
     if (m_exist(m_param,'m_tr_class_1' )) {table.rows[i].className=m_param['m_tr_class_'+((i) %2)] ;}
     if (m_exist(m_param,'m_td_classes'))
        {var trElem=table.rows[i];
         for (var j=0;j<trElem.cells.length-1;j++)
          trElem.cells[j].className=m_param['m_td_classes'][(i % 2)][j];
        }
    }


}
function ts_getInnerText(el) {
	if (typeof el == "string") return el;
	if (typeof el == "undefined") { return el };
	if (el.innerText) return el.innerText;	//Not needed but it is faster
	var str = "";
	
	var cs = el.childNodes;
	var l = cs.length;
	for (var i = 0; i < l; i++) {
		switch (cs[i].nodeType) {
			case 1: //ELEMENT_NODE
				str += ts_getInnerText(cs[i]);
				break;
			case 3:	//TEXT_NODE
				str += cs[i].nodeValue;
				break;
		}
	}
	return str;
}

function ts_resortTable(lnk,clid) {
    // get the span
    var span;
    for (var ci=0;ci<lnk.childNodes.length;ci++) {
        if (lnk.childNodes[ci].tagName && lnk.childNodes[ci].tagName.toLowerCase() == 'span') span = lnk.childNodes[ci];
    }
    var spantext = ts_getInnerText(span);
    var td = lnk.parentNode;
    var column = clid || td.cellIndex;
    var table = getParent(td,'TABLE');
    
    // Work out a type for the column
    if (table.rows.length <= 1) return;
    var itm = m_param['m_td_sort'][column];
    sortfn = ts_sort_caseinsensitive;
//    if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d$/)) sortfn = ts_sort_date;
//    if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d$/)) sortfn = ts_sort_date;
//    if (itm.match(/^[�$]/)) sortfn = ts_sort_currency;
    if (itm=='num')  sortfn = ts_sort_numeric;
    if (itm=='time') sortfn = ts_sort_time;
//    alert(itm);
//    alert(sortfn);
    SORT_COLUMN_INDEX = column;
    var firstRow = new Array();
    var newRows = new Array();
    for (i=0;i<table.rows[1].length;i++) { firstRow[i] = table.rows[1][i]; }
//save last_row
//    alert(m_class_name+'_bottom');
    var last_row=document.getElementById(m_class_name+'_bottom');

    for (j=1;j<table.rows.length-1;j++) { newRows[j-2] = table.rows[j]; }

    newRows.sort(sortfn);
    if (span.getAttribute("sortdir") == 'down') {
        ARROW = '&nbsp;&uarr;';
        newRows.reverse();
        span.setAttribute('sortdir','up');
    } else {
        ARROW = '&nbsp;&darr;';
        span.setAttribute('sortdir','down');
    }
    
    // We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
    // don't do sortbottom rows
    for (i=0;i<newRows.length;i++) {if (!newRows[i].className || (newRows[i].className && (newRows[i].className.indexOf('sortbottom') == -1))) {
	 if (m_exist(m_param,'m_tr_class_1' )) {newRows[i].className=m_param['m_tr_class_'+((i+1) %2)] ;}
	 table.tBodies[0].appendChild(newRows[i]);
	}
   }
	ts_makeColor(table);
    // do sortbottom rows only
    for (i=0;i<newRows.length;i++) { 
    if (newRows[i].className && (newRows[i].className.indexOf('sortbottom') != -1))
         table.tBodies[0].appendChild(newRows[i]);
      }
 
//restore last row
    if(last_row) table.tBodies[0].appendChild(last_row);    
    // Delete any other arrows there may be showing
    var allspans = document.getElementsByTagName("span");
    for (var ci=0;ci<allspans.length;ci++) {
        if (allspans[ci].className == m_class_name+'_sortarrow') {
            if (getParent(allspans[ci],"table") == getParent(lnk,"table")) { // in the same table as us?
                allspans[ci].innerHTML = '&nbsp;&nbsp;';
            }
        }
    }
        
    span.innerHTML = ARROW;
}

function getParent(el, pTagName) {
	if (el == null) return null;
	else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase())	// Gecko bug, supposed to be uppercase
		return el;
	else
		return getParent(el.parentNode, pTagName);
}
function ts_sort_date(a,b) {
    // y2k notes: two digit years less than 50 are treated as 20XX, greater than 50 are treated as 19XX
    aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
    bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);
    if (aa.length == 10) {
        dt1 = aa.substr(6,4)+aa.substr(3,2)+aa.substr(0,2);
    } else {
        yr = aa.substr(6,2);
        if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
        dt1 = yr+aa.substr(3,2)+aa.substr(0,2);
    }
    if (bb.length == 10) {
        dt2 = bb.substr(6,4)+bb.substr(3,2)+bb.substr(0,2);
    } else {
        yr = bb.substr(6,2);
        if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
        dt2 = yr+bb.substr(3,2)+bb.substr(0,2);
    }
    if (dt1==dt2) return 0;
    if (dt1<dt2) return -1;
    return 1;
}
function ts_sort_time(a,b) {
 aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
 bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);
 var reg=/:\d\s*$/;
 var reg2=/:/;
 if (aa.match(reg)){
  aa=aa.replace(reg2,'0');
  bb=bb.replace(reg2,'0');
 }else {
  aa=aa.replace(reg2,'');
  bb=bb.replace(reg2,'');
 } 
// alert(aa+':'+bb);
 return parseFloat(aa) - parseFloat(bb);
}
function ts_sort_currency(a,b) { 
    aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
    bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
    return parseFloat(aa) - parseFloat(bb);
}

function ts_sort_numeric(a,b) { 
    aa = parseFloat(ts_getInnerText(a.cells[SORT_COLUMN_INDEX]));
    if (isNaN(aa)) aa = 0;
    bb = parseFloat(ts_getInnerText(b.cells[SORT_COLUMN_INDEX])); 
    if (isNaN(bb)) bb = 0;
    return aa-bb;
}

function ts_sort_caseinsensitive(a,b) {
    aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).toLowerCase();
    bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).toLowerCase();
    if (aa==bb) return 0;
    if (aa<bb) return -1;
    return 1;
}

function ts_sort_default(a,b) {
    aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
    bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);
    if (aa==bb) return 0;
    if (aa<bb) return -1;
    return 1;
}


function addEvent(elm, evType, fn, useCapture)
// addEvent and removeEvent
// cross-browser event handling for IE5+,  NS6 and Mozilla
// By Scott Andrew
{
  if (elm.addEventListener){
    elm.addEventListener(evType, fn, useCapture);
    return true;
  } else if (elm.attachEvent){
    var r = elm.attachEvent("on"+evType, fn);
    return r;
  } else {
    alert("Handler could not be removed");
  }
} 
