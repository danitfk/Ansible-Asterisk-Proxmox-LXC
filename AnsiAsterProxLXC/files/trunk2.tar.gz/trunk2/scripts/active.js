window.setTimeout(reload_active,1000 );


var info="";
function active_list_get_ok(obj){
// $("#main").html("");
 info=obj[0];
 tab="";
 info.forEach(function(item, i, arr) {
	tab=tab+"<TR>";
	item.forEach(function(val, i, arr){
		tab=tab+"<TD>"+val+"</TD>";
	})
	tab=tab+"</TR>";
 });
 tab=tab+'<TR id="m_table_bottom"><TD class="bottom_header" colspan=13><input type="button" onclick="javascript:reload_active()" value="Reload"</td></tr>';
 $("#main").html(tab);
// var str=$("#m_table_bottom").html();
// $("#main").html($("#main").html()+str);
 mtables_init();
 change_colors();
}


function reload_active(){
 var upd_req={
                action: "active",
                }
         $.getJSON(
         'active_json.pl',
         upd_req ,
         active_list_get_ok
        )
 window.setTimeout(reload_active,1000 );
        return false;

}

function change_colors(){
  $('#main tr td.disc_time:contains("-")').parent().addClass("active_call");
}
