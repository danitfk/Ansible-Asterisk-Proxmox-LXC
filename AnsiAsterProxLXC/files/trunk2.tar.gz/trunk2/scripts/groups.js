function check_type(){
 if($("#type option:selected").attr("value") == "4"){
	$("#hideparam").show();
 }else{
	$("#hideparam").hide();
 }
  
}
