#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");


#start block
my $mname="";
print html_header;

my %vars= (  top => util_top('Templates',$who).util_top_menu('Templates'),tab=>html_table(db_query("select 
   concat('<a href=\"template_edit.pl?id=',id,'\" >E</a> <a href=\"template_del.pl?id=',id,'\" >D</a>'
) as action,
	concat(trunk_type,'/',name),concat('<pre>',value,'<pre>')

  from trunks_template
   order by name"))
);

print util_template("templates/Templates.tmpl",\%vars);
