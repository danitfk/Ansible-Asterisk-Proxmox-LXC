#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;

db_query_exec("create table if not exists trunks_cdr(
  number varchar(200) NOT NULL default '',
  dialled varchar(200) NOT NULL default '',
  stoptime timestamp NOT NULL default CURRENT_TIMESTAMP,
  trunk_id int(11) default NULL,
  group_id int(11) default NULL,
  trunk_type varchar(10) default 'SIP',
  billsec int(11) default '0',
  cost decimal(16,5) default NULL,
  uniq varchar(32) default NULL,
  KEY `trunks_cdr_get` (`number`,`stoptime`)
)");
db_query_exec("create table if not exists trunks_trunk
(
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `cost` decimal(16,5) default 0,
  `name` varchar(50) default '-',
  descr varchar(100) default '',
  `ip` varchar(100) not null,
  `secret` varchar(20) not null, 
  `template_id` int(11) not null,
  `in_dial` int(11) default 0,
  `max_count` int(11) default '1',
  `paused` tinyint(1) default 0,
  `auto_pause_1` tinyint(1) default 0,
  `auto_pause_2` tinyint(1) default 0,
  `auto_pause_3` tinyint(1) default 0,
  `c` bigint(20) default 0,
  `ok` bigint(20) default 0,
  `sum` bigint(20) default 0,
  `last_checked` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `trunk_type` varchar(10) default 'SIP',
  UNIQUE KEY `id` (`id`)
) engine= 'innodb'
");

db_query_exec("create table if not exists trunks_template
(
  `id` serial,
  `name` varchar(100) default '',
   trunk_type varchar(5) default 'SIP',
   value text
);
");

db_query_exec("create table if not exists trunks_rules
( id serial,
  trunk_id integer,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  allow boolean default 1,
  key(trunk_id,ext_prefix)
)"
);
db_query_exec("create table if not exists trunks_group_rules
( id serial,
   group_id integer,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  allow boolean default 1,
  key(group_id,ext_prefix)
)"
);


db_query_exec("create table if not exists trunks_group
(
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `priority` integer default 0,
  descr varchar(100) default '',
  `type` int(11) not null,
  `in_dial` int(11) default 0,
  `max_count` int(11) default '1',
  `paused` tinyint(1) default 0,
  `auto_pause_1` tinyint(1) default 0,
  `auto_pause_2` tinyint(1) default 0,
  `auto_pause_3` tinyint(1) default 0,
  `c` bigint(20) default 0,
  `ok` bigint(20) default 0,
  `sum` bigint(20) default 0,
  `last_checked` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) engine= 'innodb'
");

db_query_exec("create table if not exists trunks_trunk2group
(
  id serial,
  gid integer,
  tid integer,
  key(gid),
  key(tid)
);
");


db_query_exec("create table if not exists trunks_agent
(
  id serial,
  name varchar(100) not null,
  in_dial integer default 0,
  max_count integer default 10,
  prefix varchar(10),
  flags varchar(20),
  paused boolean default 0,
  emails text,
  descr text
)
");

db_query_exec("create table if not exists trunks_agent_ip
(
  id serial,
  ip bigint unique,
  agent_id integer
);
");

db_query_exec("create table if not exists trunks_agent_rules
( id serial,
   agent_id integer,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  name text,
  cost numeric(16,5) default 0,
  first integer default 1,
  interv integer default 1,
  min integer default 1,
  
  in_dial integer default 0,
  max_count integer default 10,

  allow boolean default 1,
  key(agent_id,ext_prefix)
)"
);
