#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;
use CGI::Upload;
use Text::CSV;
use POSIX qw(strftime);

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
my $id=$cgi->param('id');
unless($id){
	print html_redirect("Agents.pl");
	exit;
}
my $aid=$cgi->param('aid');
unless($cgi->param('prefix')){
  unless($cgi->param("file_upload")){
  }else{## uplaod file 
	my $upload = CGI::Upload->new();
        my $upload_filehandle= $upload->file_handle('csv');
        my $filename= $upload->file_name('csv');
        my $file_type = "$filename"; $file_type=~s/.*\.(.{3})/$1/;
        if(!($file_type eq "csv")){
                        print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid&error=File_must_be_csv");
                       exit;
        }

        $filename="upload_".strftime("%a_%b_%e_%H_%M_%S_%Y", localtime()).".".$file_type;
        open UPLOADFILE, ">/tmp/$filename";
        binmode UPLOADFILE;
        while ( <$upload_filehandle> )
        {
           print UPLOADFILE;
        }
        close UPLOADFILE;
        my $csv = Text::CSV->new();
        open (CSV, "<", "/tmp/$filename") or die $!;
        while (<CSV>) {
              if ($csv->parse($_)) {
               my @columns = $csv->fields();
               my ($prefix)=$columns[0];
	       $prefix=~"s/a-z,A-Z,\ \t//g";
	       if($prefix eq ""){}else{
		
		my $cost=0;
	        my $name="'sub'";
        	my $max_count= 0;
	        $prefix=~s/\s+//g;
	        my $pos=index($prefix,'+');
	        my $add_prefix='';
	        if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
db_query_exec("insert into trunks_agent_rules(ext_prefix,add_prefix,strip,agent_id,allow,cost,name,max_count,parent)
                         values('$prefix','$add_prefix','$strip',$aid,1,$cost,$name,$max_count,$id)");


	 	}
              } else {
                        my $err = $csv->error_input;
                        $err=~s/ /_/g;
                        print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid&error=Failed_to_parse_$err");
                        exit;
              }
       }
       db_commit();
       close CSV;

  }
}else{
	my $cost=0;
	my $prefix=$cgi->param('prefix');
	my $name="'sub'";
	my $max_count= 0;
         $prefix=~s/\s+//g;
         my $pos=index($prefix,'+');
         my $add_prefix='';
         if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
db_query_exec("insert into trunks_agent_rules(ext_prefix,add_prefix,strip,agent_id,allow,cost,name,max_count,parent)
                         values('$prefix','$add_prefix','$strip',$aid,1,$cost,$name,$max_count,$id)");
	db_commit();
	
}
print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid");
