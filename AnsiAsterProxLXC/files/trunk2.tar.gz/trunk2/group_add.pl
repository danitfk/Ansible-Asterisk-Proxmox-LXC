#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
unless($cgi->param('priority')){
my %vars= (  top => util_top('Groups - Add Group',$who).util_top_menu('Groups'),
	descr => 'Group',priority=>1,max_count=>5,allow=>'[0-9]'
);
	
	  my $type=$vars{'type'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
 	\$('#adds').hide();
	check_type();
  }
 )
";
	print html_header;
	print util_template("templates/group_edit.tmpl",\%vars);
} else {
	my ($max_count,$descr,$priority,$type,$type_param)=($cgi->param('max_count'),$cgi->param('descr'),$cgi->param('priority'),
	$cgi->param('type'),$cgi->param('type_param'));
	unless($type_param){$type_param=1000;}
	db_query_exec("insert into trunks_group (descr,priority,max_count,type,type_param) values (
	".db_quote($descr).",$priority,$max_count,$type,$type_param)");
	db_commit();
	
	my $id=db_query_one("select id from trunks_group where descr=".db_quote($descr)." order by id desc limit 1");
	foreach(("allow","deny")){
                my $pallow=$_;
                my $allow=0;
                if($pallow eq "allow"){$allow=1;};
        foreach(split(/\n/,$cgi->param($pallow))){
                my $prefix=$_;
                $prefix=~s/\s+//g;
                my $pos=index($prefix,'+');
                my $add_prefix='';
                if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
                db_query_exec("insert into trunks_group_rules(ext_prefix,add_prefix,strip,group_id,allow)
                         values('$prefix','$add_prefix','$strip',$id,$allow)");
        }
        }#alow,deny

	print html_redirect("Groups.pl");

}
