#!/usr/bin/perl -I.
#use mlib::db;
#my $con=Mconnect;
#db_query_exec_("update  trunks_trunk set in_dial=0,last_checked=now()",$con);
#db_commit_($con);

use TrunkAGI;
#use mlib::db;
#db_query_exec("update  trunks_trunk set in_dial=0,last_checked=now()");
#db_commit();

TrunkAGI->version();
my $port=$ARGV[0];
unless($port){$port=`cat port.opt`;};
print "starting at port $port\n";

TrunkAGI->run(port=>$port,min_servers => 1,min_spare_servers=>1,max_spare_servers=>10,check_for_spawn=>3,max_servers=>500,log_level=>4,child_communication=>1);
