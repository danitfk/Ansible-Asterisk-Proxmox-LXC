#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::options;
use mlib::session;
use CGI;
use DBI;
use JSON;
use CGI ':standard';
use CGI::Carp qw(fatalsToBrowser);


my $cgi=new CGI;
my $action=$cgi->param('action');

if ($action eq 'create'){
        print javascript_header($cgi);
        db_query_exec('update trunks_agent_rules set rule_type=3 where id='.$cgi->param('id'));
	db_commit();
        print JSON->new->encode([1]);
}elsif($action eq 'get'){
	print javascript_header($cgi);
	print JSON->new->encode([db_query("select id,case when rule_type=1 then
                 concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                    case when strip=0 then  ext_prefix else
                      concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                     end
                    )
                when rule_type=2 then
                 concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, from_n,'-',to_n)
                end   
                     from trunks_agent_rules where parent=".$cgi->param('id')." order by id"),
		db_query_one("select count(*) from trunks_agent_rules where parent=".$cgi->param('id'))
	]);
}elsif($action eq "save_info"){

	print javascript_header($cgi);
	my $info=" cost=".$cgi->param('cost').", name=".db_quote($cgi->param('name')).", max_count=".$cgi->param('max_count');
	my $id=$cgi->param('id');
        db_query_exec("update trunks_agent_rules set $info where id=$id or parent=$id");
	db_commit();
        print JSON->new->encode([1]);
}
