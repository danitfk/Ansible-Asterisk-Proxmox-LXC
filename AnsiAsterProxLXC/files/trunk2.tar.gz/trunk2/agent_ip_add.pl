#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
my $id=$cgi->param('id');
unless($id){
	print html_redirect("Agents.pl");
	exit;
}
unless($cgi->param('ip')){
}else{
	my $ip=$cgi->param('ip');
	my @parts=split(/-/,$ip);
	$ip=$parts[0];
	my @IP=split(/\./,$ip); 
	if ( ($IP[0] < 256 && $IP[0] > 0) && ($IP[1] < 256 && $IP[1] >= 0) && ($IP[2] < 256 && $IP[2] >= 0) &&  ($IP[3] < 256 && $IP[3] > 0)) {
		my $start=$IP[0].".".$IP[1].".".$IP[2].".";
		my ($a,$b)=($IP[3],$IP[3]);
		unless($parts[1]){} else{
			if ($parts[1]=~m/\d{1,3}/){
				if ($parts[1]>$b){$b=$parts[1];};
			}
		}
		for(my $i = $a; $i <= $b; $i++) {
			$ip=$start."$i";
			my $ex=db_query_one("select agent_id from trunks_agent_ip where ip=INET_ATON(".db_quote($ip).")");
			unless($ex){
				db_query_exec("insert into trunks_agent_ip(ip,agent_id) select INET_ATON(".db_quote($ip)."),$id;");
				db_commit();
			}else{
				 $ex=db_query_one("select name from  trunks_agent where id=$ex");
				 $ex=~s/[^a-z]/_/gi;
				 print html_redirect("agent_edit.pl?id=$id&error=Sorry_ip_exist_at_agent_$ex");
				 exit;
			}
		}
	}else{
			print html_redirect("agent_edit.pl?id=$id&error=ip_has_wrong_format");
			exit;
	}
	
}
 print html_redirect("agent_edit.pl?id=$id");
