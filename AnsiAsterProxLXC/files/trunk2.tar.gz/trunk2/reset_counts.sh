#/bin/bash
for i in trunks_trunk trunks_group
do
echo $i
echo "update $i set c =0,ok=0,sum=0;
"|/usr/bin/mysql asterisk -u trunk2 --password=mtest -s -h mysql
done;
echo "delete from trunks_counts"|/usr/bin/mysql asterisk -u trunk2 --password=mtest -s -h mysql
