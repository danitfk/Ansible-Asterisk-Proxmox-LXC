#!/usr/bin/perl
use Text::Template;
my $DBH=`cat /etc/faxserver.conf|grep DBHOST|cut -f 2 -d '='`;
my $DBP=`cat /etc/faxserver.conf|grep DBPASSWORD|cut -f 2 -d '='`;
my $DBU=`cat /etc/faxserver.conf|grep DBUSER|cut -f 2 -d '='`;
my $DBN=`cat /etc/faxserver.conf|grep DBNAME|cut -f 2 -d '='`;
$DBH=~s/\s//g;
$DBP=~s/\s//g;
$DBU=~s/\s//g;
$DBN=~s/\s//g;
my $file="options.pm";
my $DBC;
 $DBC="dbi:mysql:dbname=$DBN;host=$DBH";
if ($DBH eq "localhost")
{
 $DBC="dbi:mysql:dbname=$DBN"; 
};
if ($DBH eq "127.0.0.1")
{
 $DBC="dbi:mysql:dbname=$DBN"; 
};

 open FILE, ">$file" or die "unable to open $file $!";
 my %vars= (  DBC =>$DBC,DBU=> $DBU, DBP=> $DBP
 );
 print FILE util_template("options.tmpl",\%vars);



sub util_template {
   my ($file,$vars)=@_;
   my $template = Text::Template->new(SOURCE => $file);
   unless ($template) {die "Couldn't open template $file"};
   my $tmplresult = $template->fill_in(HASH => $vars);
   if ( $tmplresult) {return $tmplresult;}else{
    die "Couldn't fill in template";};
}
