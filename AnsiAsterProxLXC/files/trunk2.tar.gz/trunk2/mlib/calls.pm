#!/usr/bin/perl
use warnings;
use strict;
use mlib::options;
use mlib::db;
use mlib::utils;
use Text::Template;





BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw();
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();



    }
{

#use constant DEBUG => 1;



sub call_application {
 my ($number,$uid,$application,$params)=@_;
 my $tmp="";
 my ($FILEWRITE)=get_tmp_call();
 my $callerid=get_user_option($uid,'core_callerid');
 print $FILEWRITE "Channel: Local/$number\@out_$uid
MaxRetries: 3
RetryTime: 35
WaitTime: 35
CallerID: <$callerid>
Application: $application
Data: $params
";
 close ($FILEWRITE);
 `mv $FILEWRITE /var/spool/callweaver/outgoing/`;
 return 1;
}
sub call_reload {
 db_query_exec("update options set value=1 where opt='reload'");
 db_commit();
 #`/www/rcallweaver.pl reload`;
 return 1;
}
sub openser_reload_cr {
 db_query_exec("update options set value=1 where opt='reload_cr'");
 db_commit();
}
sub next_mailbox_by_uid {
  my ($uid)=@_;
  $uid=~s/0/a/g;
  $uid=~s/1/b/g; 
  $uid=~s/2/c/g;
  $uid=~s/3/d/g;
  $uid=~s/4/e/g;
  $uid=~s/5/f/g;
  $uid=~s/6/g/g;
  $uid=~s/7/h/g;
  $uid=~s/8/k/g;
  $uid=~s/9/l/g;
  my $inital_name=$uid;my $c=1;
   while ((db_query_one("select count(*) from voicemail_users where   mailbox=".db_quote($inital_name.$c)))){
    $c++;
  }
 $uid=$inital_name.$c;
 return $uid;
}
#END { 
}
1;

