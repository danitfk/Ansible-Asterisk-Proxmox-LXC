package options;

BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&func1 &func2 &func4);
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw( db_connect_string db_user db_password db_options);
    }
{
use constant {
 main_name => "Trunk 2.0",
 db_connect_string2 => "dbi:mysql:dbname=asteriskcdrdb",
 db_connect_string => "dbi:mysql:host=mysql;dbname=asterisk",
 menu => "Agents,Groups,Trunks,Templates,BlackList,Active,Settings,Logout",
 db_user => "trunk2",
 db_password => "mtest",
 db_options=>{
	PrintError => 1,
        AutoCommit => 0}
}
}
END { }
1;	
