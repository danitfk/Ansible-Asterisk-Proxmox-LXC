#!/usr/bin/perl
use warnings;
use strict;
use mlib::options;
use mlib::db;
use Digest::MD5 qw(md5 md5_hex md5_base64);


BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&session_login );
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();



    }
{


sub session_login {
 my ($sentuser,$sentpword)=@_;
 unless (defined($sentuser) && defined($sentpword) && $sentuser && $sentpword) {
  return undef;
 }
 $sentuser = lc($sentuser);
# $sentpword = lc($sentpword);
 my $sql="select id,login_name,password,language from users where login_name=".db_quote($sentuser)." and password = md5(".db_quote("$sentuser$sentpword").")";
 my $res=db_query_hash($sql);

 unless( $res->{'id'}) { return undef;};
 return session_login_as($res);
}
sub session_login_as{
 my ($res)=(@_);
 my $ses=db_session();
 $ses->param('uid',$res->{'id'});
 $ses->param('language',$res->{'language'});
 unless($res->{'firstname'}){$ses->param('first',' ');}else{
         $ses->param('first',$res->{'firstname'});
 }
 $ses->param('login_name',$res->{'login_name'});
 unless($res->{'lastname'}){
        $ses->param('last',' ');
 }else{
        $ses->param('last',$res->{'lastname'});
 }
 $ses->param('login',$res->{'login_name'});
 if($res->{'id'} == 1){
         $ses->param('access',1);
 }else{
         $ses->param('access',2);
 }
 return $ses;
}

sub session_get {
 my ($sid)=@_;
 return db_session($sid);
}


sub session_cookie {
 my ($cgi,$ses)=@_;
 unless(defined ($cgi)&& defined ($ses) && $ses && $cgi )
  {
   return undef;
  }
 else {
    my $cookie = $cgi->cookie(CGISESSID => $ses->id);
    return $cgi->header( -cookie=>$cookie );
 }
}

sub session_check {
 my ($cgi)=@_;
 unless(defined ($cgi)) {
   return undef;
 } else {
  my $SID = $cgi->param("SESSION_ID");
  unless($SID){
        $SID=$cgi->cookie("CGISESSID") || undef;
  }

#  print $a;
  unless($SID){
        print html_redirect("index.pl");
        return undef;
  }
  my $ses= session_get($SID);
  unless($ses){
        print html_redirect("index.pl");
         return undef;
  }
  unless($ses->param('uid')){
        print html_redirect("index.pl");
         return undef;

  }
  return $ses;
 }
}

sub ses_allow{
  my ($ses,$page)=@_;
  $page=~s/.*trunk2\///;
  $page=~s/\.pl//;
  if($page eq "active_json"){$page="Active";}
  unless(db_query_one("select 1 from user2page where user_id=".session_uid($ses)." and ( pagename = '*' or '$page' = pagename)")){
	print html_header();
	print 'not allowed access to '.$page.' for user '.session_uid($ses).'<BR>';
	print '<a href="Logout.pl">OK</a>';
	return 0;
  }
  return 1;
}

sub session_uid{
        my ($ses)=@_;
	unless($ses){ return -1;}
        my $uid=$ses->param('uid');
	unless($uid){ return -1;}
}

}
#END { }
1;
