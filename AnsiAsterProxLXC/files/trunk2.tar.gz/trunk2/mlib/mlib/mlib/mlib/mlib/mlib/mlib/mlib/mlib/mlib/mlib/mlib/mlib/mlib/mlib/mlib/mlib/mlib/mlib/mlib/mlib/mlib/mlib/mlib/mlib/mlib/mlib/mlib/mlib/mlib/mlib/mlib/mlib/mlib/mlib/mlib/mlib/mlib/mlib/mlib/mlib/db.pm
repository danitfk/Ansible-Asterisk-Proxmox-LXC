#!/usr/bin/perl
use warnings;
#ause strict;
use mlib::options;
use CGI::Session ( '-ip_match' );
use DBI;
sub Mconnect {
# printf (options::db_connect_string) if DEBUG >10;
 return DBI->connect(options::db_connect_string,options::db_user,options::db_password,options::db_options);
}
my $dbh;
BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&db_query &db_quote &db_query_exec &db_copy_array);
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();


	$dbh = Mconnect();
    }
{

#use constant DEBUG => 1;




#asub Mconnect {
# printf (options::db_connect_string) if DEBUG >10;
# return DBI->connect(options::db_connect_string,options::db_user,options::db_password,options::db_options);
#}


sub db_query {
	my ($query)=(@_);
	$dbh->ping() or $dbh=Mconnect();


        my $sth=$dbh->prepare($query);
	$sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
	my $res= $sth->fetchall_arrayref();
        return $res;
}
sub db_query_ {
        my ($query,$dbh)=(@_);
	$dbh->ping() or $dbh=Mconnect();
        my $sth=$dbh->prepare($query);
        $sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
        my $res= $sth->fetchall_arrayref();
        return $res;
}

sub db_query_one {
        my ($query)=@_;
	my $a=db_query ($query);
 	return undef unless $a;
	return undef unless ref @{$a}[0];
        return @{$a}[0]->[0];
}
sub db_query_one_ {
 my ($query,$dbh)=(@_);
 $dbh->ping() or $dbh=Mconnect();
 my $a=db_query_($query,$dbh);
        return undef unless $a;
        return undef unless ref @{$a}[0];
        return @{$a}[0]->[0];
}
sub db_query_hash {
	my ($query)=(@_);
        #print "$query\n\n";
        $dbh->ping() or $dbh=Mconnect();
	my $sth=$dbh->prepare($query);
         $sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
       return $sth->fetchrow_hashref;
}
sub db_query_hash_ {
my ($query,$dbh)=(@_);
        #print "$query\n\n";
        $dbh->ping() or $dbh=Mconnect();
        my $sth=$dbh->prepare($query);
         $sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
       return $sth->fetchrow_hashref;
}

sub db_query_exec{
	my ($query)=@_;
        $dbh->ping() or $dbh=Mconnect();

	#print $query;
        my $sth=$dbh->prepare($query);
        $sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
	return $sth;
}
sub db_query_exec_{
        my ($query,$dbh2)=@_;
	$dbh2->ping() or $dbh2=Mconnect();
        #print $query;
        my $sth=$dbh2->prepare($query);
        $sth->execute() or die "on DB query -$query- error sql:".$sth->errstr;
        return $sth;
}
sub db_check_ {
	my ($dbh)=@_;
	$dbh->ping() or $dbh=Mconnect();
	return $dbh;
}

sub db_query_array {
 my ($query)=@_;
 my $input=db_query($query);
 my @array;
 for my $i (@{$input}){
  push(@array,@{$i}[0])
 }
 return \@array;
}
sub db_commit{
	$dbh->commit();
	} 
sub db_commit_{
 my ($dbh2)=@_;
        $dbh2->commit();
        }
sub db_rollback_{
 my ($dbh2)=@_;
        $dbh2->rollback();
        }
sub db_quote {
	my ($query)=@_;
	unless($query){
		$query="";
	};
        return $dbh->quote($query);
}
sub db_copy_array{
 my ($query,$array)=@_;
 $dbh->do($query);
  for my $i (@{$array}){
	$dbh->pg_putline($i);
    }
 $dbh->pg_endcopy();
 $dbh->commit();
 return 1;
}
}
sub db_copy_to_stdin{
  my ($query)=@_;
  $dbh->do($query);
  my $data="";
  my $x=0;
  while($dbh->pg_getline($data, 1000)){
	$data=~s/(;\d+\.[1-9]*0)0+;/$1;/g;
	print $data;};
 
}
sub db_copy_to_stdin_table{
  my ($query)=@_;
  $dbh->do($query);
  my $data="";
  my $x=0;
  while($dbh->pg_getline($data, 1000)){
        $data=~s/(;\d+\.[1-9]*0)0+;/$1;/g;
	$data=~s/;/<td>/g;
        print '<tr><td>'.$data.'</tr>';};

}
sub db_session {
 $dbh->ping() or Mconnect();
# CGI::Session::NAME="ModularByMeral";
 my $s=new CGI::Session( "driver:mysql", undef, { Handle => $dbh } ); 
# $s->name("ModularByMeral");
 return $s;
}


END { $dbh->disconnect();}
1;

