#!/usr/bin/perl
use warnings;
use strict;
use mlib::options;
use mlib::db;
use Text::Template;
use File::Temp;




BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&sheduler_get_times);
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();



    }
{

#use constant DEBUG => 1;




sub sheduler_is_enabled{
 my ($project,$day,$hour)=@_;
 
 my $en= db_query_one("select enable from dialler_sheduler where project_id=$project and day=$day and hour=$hour  order by id limit 1");
 unless ($en){
  return get_project_option($project,'default_sheduler');
 }else {
  return $en;
 }
# dialler_sheduler(id serial, day integer, hstart integer,hend integer,enable  boolean);
}
sub sheduler_set{
 my ($project,$day,$hour,$state)=@_;
 if ($state==2){
  db_query_exec("delete from dialler_sheduler where project_id=$project and day=$day and hour=$hour");
 }else{
  my $en=db_query_one("select 1 from dialler_sheduler where project_id=$project and day=$day and hour=$hour ");
  unless($en){
   db_query_exec("insert into dialler_sheduler(project_id,day,hour,enable) values($project,$day ,$hour,$state)");
  }else { 
    db_query_exec("update dialler_sheduler set enable=$state where project_id=$project and day=$day and hour=$hour");
  }
 }
}


#END { 
}
1;

