#!/usr/bin/perl
use warnings;
use strict;
use mlib::options;
use CGI;
use Text::Template;

BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&html_select &html_header &html_mazda_header);
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();



    }
{

use constant DEBUG => 1;


sub html_select{
 my ($input,$adds)=@_;
 my $s='<select ';
 if ($adds) {$s.=$adds};
 $s.='>';
 my $selected="";
# print $selected;
  for my $i (@{$input}){
    if (@{$i}[2]) {$selected=' selected="selected" ';} else {$selected="";};
    if (defined @{$i}[1]  ){
     $s.='<option value="'.@{$i}[1];
    }
    else
     {
      $s.='<option value="'.@{$i}[0];
     }
    $s.='" '.$selected.'/>'.@{$i}[0];
  }

 return $s.'</select>';
}
sub html_select_boolean {
 my ($input,$adds)=@_;
 my $s='<select ';
 if ($adds) {$s.=$adds};
 $s.='>';
 if ($input){
  $s.="<option value=1 selected=selected>Yes</option><option value=0>No</option></select>";
 }
 else {
  $s.="<option value=1>Yes</option><option value=0 selected=selected >No</option></select>";
 }
 return $s;
};
sub html_session {
 my ($sid)=@_;
 return "<input type=hidden name=sid value='$sid'>";
}
sub html_table{
 my ($input)=@_;
 my $s='';
  for my $i (@{$input}){
   $s.='<TR>';
   for my $j (@{$i}){ 
    $s.="<TD>$j</TD>";
		}
   $s.='</TR>';
  }
 return $s;
}


sub html_header {
 my ($query,$sid) = @_;
 unless ($query) {$query = new CGI;}
 $query->charset('win-1251');
 return $query->header ;
}
sub tif_header {
 return "Content-Type: image/tiff\r\n\r\n";
 
}
sub csv_header {
 return "Content-Type: text/csv\r\n\r\n";
}
sub javascript_header {
 my ($cgi)=@_;
 return $cgi->header(-type=>'text/javascript',
                             -expires=>'-1d',
                             -charset=>'utf-8'
 );
} 

sub html_redirect {
 my ($URL)=@_;
 return "Status: 302 Moved\nLocation: $URL\n\n";
}

#END {
 }
1;

