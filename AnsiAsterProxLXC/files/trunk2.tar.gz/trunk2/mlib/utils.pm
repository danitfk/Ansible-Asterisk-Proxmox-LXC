#!/usr/bin/perl
use warnings;
use strict;
use mlib::options;
use mlib::db;
use Text::Template;
use File::Temp;




BEGIN {
        use Exporter   ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        # set the version for version checking
        $VERSION     = 0.01;
        # if using RCS/CVS, this may be preferred
        $VERSION = sprintf "%d.%03d", q$Revision: 0.1 $ =~ /(\d+)/g;

        @ISA         = qw(Exporter);
        @EXPORT      = qw(&str_to_hours &util_calendar  &util_calendar_scripts &util_get_zone);
        %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

        # your exported package globals go here,
        # as well as any optionally exported functions
        @EXPORT_OK   = qw();



    }
{

#use constant DEBUG => 1;






sub str_to_hours{
	my ($str)=@_;
	my $s=0;
        foreach my $i (split(/,/,$str)){
					$i=~ s/\s//g;
                                        if ($i=~/\d*-\d*/){
						my ($n1,$n2)=split(/-/,$i);
                                                for(my $j=$n1;$j<=$n2;$j++){
                                                 $s=$s|(1<<$j);
	                                        }
                                        }
                                        elsif($i=~/\d*/) {
                                         $s=$s|(1<<$i);
                                        }
                                }
        return $s;
}#sub
sub util_hours_zone{
my ($a,$z)=@_;
my $res= ($z>=0)?
(($a<< $z)&16777215) |( ($a<<$z)>>24): 
((($a<< 24)>> (0-$z) )&16777215) | (
($a>> (0-$z))
);
return $res;
}
my @month=("","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
             "Sep", "Oct", "Nov", "Dec");
sub util_calendar {
 my ($str,$date)=@_;


 if (defined $date) {
# print "-$date1--";
 my $m=$date;
 $m =~ s/^(\d\d\d\d)-(\d\d)-.*/$2/;
 $m=$month[$m];
 $date=~ s/$\s*(\d\d\d\d)-(\d\d)-(\d\d)( \d\d:\d\d)(.*)/'$m $3, $1 $4'/;
 
 }else {
  $date='';
 };
 my $template = Text::Template->new(SOURCE => 'templates/calendar.tmpl')
   or die "Couldn't construct template: $Text::Template::ERROR";
 my %vars = (calendar_out => $str, date_set =>$date);
 my $tmplresult = $template->fill_in( HASH => \%vars);

 if ( $tmplresult) {
                 return $tmplresult ;
                        }
 else
            { die "Couldn't fill in template: $Text::Template::ERROR" }

}#sub
sub util_calendar_scripts{
return '<link rel="stylesheet" type="text/css" media="all" href="/calendar.css"  />
  <script type="text/javascript" src="scripts/calendar.js"></script>
  <script type="text/javascript" src="scripts/lang/calendar-en.js"></script>
  <script type="text/javascript" src="scripts/calendar-setup.js"></script>'
}

sub util_get_zone{
 return @{db_query("select value from option where key='time'")}[0]->[0];
}
sub util_top {
 my ($menu,$who)=@_;
 my ($title,$welc);
# print html_header." - " .$who."+ $menu";
 unless ($who){
  $title=""; 
  $welc="Welcome unknown"
 } else {
  $welc="Welcome $who";
  $title="logged as $who";
 };
 unless ($menu){$menu='';} else {$menu=' - '.$menu;};
my $main_name=options::main_name;
return qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//RU">
<HTML>
<HEAD>
<title>$main_name - $menu - $title </title>
<META http-equiv="content-type" content="text/html; charset=windows-1251">
<META name="description" content="FAX-SERVER BILLING">
<META name="keywords" content="asterisk fax meral billing ">
<!--<LINK rel="shortcut icon" href="/favicon.ico"> -->
<link href="style.css" type="text/css" rel="stylesheet">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<META NAME="ROBOTS" CONTENT="NONE">
</head>
<body>
<div style="text-align: left; width: 100%;">
<img src="img/logo.gif" /><br /><br />
$welc
</div>}
}
sub util_top_menu{
my ($menu_,$ses)=@_;
        my $amenu=options::menu;
	my @menu=split(/,/,$amenu);
	  my $s='';
        $s.="<table width=\"100%\" style=\"text-align: center; \"><tr>";
        foreach (0 .. @menu-1){
                my $name=$menu[$_];
                my $text=$menu[$_];
                my $class=($name eq $menu_)? "active_top":"top";
                my $link=$name.".pl";
                $s.="<td width=\"".(sprintf("%.2f",100 / (@menu)))."%\"><a href=\"$link\"
class=\"$class\">$text</a></td>";
         };
        $s.="</tr></table>";
        return $s;


}#func
sub menu_admin {
my ($menu_,$ses)=@_;
unless ($ses) {$ses=db_session();}
my $str_result; my $menu_hash; my $class;my $array_menu;
        my @menu=split(/,/,get_option('menu_admin'));
        my $s='';
        $s.="<table width=\"100%\" style=\"text-align: center; \"><tr>";
        foreach (0 .. @menu-1){
                my $name=$menu[$_];
                my $text=$menu[$_];
                $class=($name eq $menu_)? "active_top":"top";
                my $link=$name.".pl";
                $s.="<td width=\"".(sprintf("%.2f",100 / (@menu)))."%\"><a href=\"$link\"
class=\"$class\">$text</a></td>";
         };
        $s.="</tr></table>";
        return $s;

}#func

sub util_get_rpp {return 50;};

sub util_template {
   my ($file,$vars)=@_;
   my $template = Text::Template->new(SOURCE => $file);
   unless ($template) {die "Couldn't open template $file"}; 
   my $tmplresult = $template->fill_in(HASH => $vars);
   if ( $tmplresult) {return $tmplresult;}else{ die "Couldn't fill in template: $Text::Template::ERROR" }
}
sub get_user_option {
   my ($uid,$opt)=@_;
  my $tres=db_query_one("select value from user_options where opt=".db_quote($opt)." and user_id=".$uid);
  return $tres;
}
sub get_project_option {
  my ($pid,$opt)=@_;
  my $tres=db_query_one("select value from dialler_options where opt=".db_quote($opt)." and project_id=".$pid);
  return $tres;
}
sub set_user_option  {
  my ($uid,$opt,$val,$new)=@_;
  my $a=db_query_one("select count(*) from  user_options where opt=".db_quote($opt));
  if ($a==0){
    db_query_exec("insert into  user_options (value,opt,user_id) values
       (".db_quote($val).",".db_quote($opt).",".$uid.")");
   return 1;
  }
  $a=db_query_one("select count(*) from  user_options where opt=".db_quote($opt)." and  value=".db_quote($val) );
  if ($a==0){
  db_query_exec("update user_options set value=".db_quote($val)." where opt=".db_quote($opt)." and
user_id=".$uid);
  return 1;
  }
  return 0;
}

sub get_option {
 my ($opt)=@_;
 return db_query_one("select value from options where opt=".db_quote($opt));
}

sub get_tmp_call {
# return   mkstemps( "tmpfileXXXXX" ,".call");
 return new File::Temp( UNLINK => 0, SUFFIX => '.call' );
 
}

#END { 
}
1;

