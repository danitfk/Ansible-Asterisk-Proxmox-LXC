#/bin/bash
echo "update trunks_trunk set in_dial=0,last_checked=now() ;
update trunks_group set in_dial=0,last_checked=now() ;
update trunks_agent set in_dial=0;
update trunks_agent_rules set in_dial=0;
"|/usr/bin/mysql asterisk -u trunk2 --password=mtest -s -h mysql
echo "truncate table trunks_counts"|/usr/bin/mysql asterisk -u trunk2 --password=mtest -s -h mysql
