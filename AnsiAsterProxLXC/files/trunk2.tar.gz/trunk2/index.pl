#!/usr/bin/perl -I .


use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::calls;
use mlib::session;
use CGI;
use CGI ':standard';
use CGI::Carp qw(fatalsToBrowser);
use DBI;
use JSON;
use Data::Dumper;

my $cgi=new CGI;

#check if session ok. if nto redirect to login

print html_header;


my %vars;
my $error=$cgi->param("error");
unless($error){$error='';}else {$error=~s/_/ /g};
$vars{'error'}=$error;

my $script=' $(document).ready(function() {
        $("#welcome").html("Welcome! Please log in!");
        $("#logout").html("");
        $(".menu").hide();
});';

$vars{'script'}=$script;
my $content=util_template("templates/login.tmpl",\%vars);
print $content;
