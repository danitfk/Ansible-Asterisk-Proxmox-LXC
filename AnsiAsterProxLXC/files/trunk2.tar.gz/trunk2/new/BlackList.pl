#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;
use Data::Dumper;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';


sub get_rules{
        my ($rule)=(@_);
        my $rows=db_query_array("select 
        concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as prefix from trunks_blacklist_rules where whitelist=$rule");
        return join("\n",@{$rows});
}





unless($cgi->param('action')){
#        amy $row=db_query_hash("select * from trunks_blacklist_rules");

	my %vars= (  top => util_top('BlackList - Edit Trunk',$who).util_top_menu('BlackList'),
	allow=>get_rules(1),deny=>get_rules(0),);
	print html_header;
	print util_template("templates/blacklist_edit.tmpl",\%vars);
} else {

	
	db_query_exec("delete from trunks_blacklist_rules");
	

	foreach(("allow","deny")){
		my $pallow=$_;
		my $allow=0;
		if($pallow eq "allow"){$allow=1;};
	foreach(split(/\n/,$cgi->param($pallow))){
		my $prefix=$_;
		$prefix=~s/\s+//g;
		my $pos=index($prefix,'+');
		my $add_prefix='';
		if ($pos>0){
		 $add_prefix=substr($prefix,0,$pos);
		 $prefix=substr($prefix,$pos+1);
		}
		my $strip=index($prefix,'|');
		if ($strip <=0){$strip=0;}
		$prefix=~s/\|//;
		db_query_exec("insert into trunks_blacklist_rules(ext_prefix,add_prefix,strip,whitelist)
		 values('$prefix','$add_prefix','$strip',$allow)");
	}
	}#alow,deny
	db_commit();
	unless($cgi->param('r')){
		print html_redirect("Trunks.pl");
	}else{
		 print html_redirect("group_edit.pl?id=".$cgi->param('i'));
	}

}


