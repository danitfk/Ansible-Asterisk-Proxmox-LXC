#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;
use Data::Dumper;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';


sub get_rules{
        my ($id,$rule)=(@_);
        my $rows=db_query_array("select 
        concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as prefix from trunks_rules where trunk_id=$id and allow=$rule");
        return join("\n",@{$rows});
}



unless($cgi->param('id')){
        print html_redirect("Trunks.pl");
        exit;
}


my $id=$cgi->param('id');
unless($cgi->param('name')){
        my $row=db_query_hash("select * from trunks_trunk where id=$id");

	my %vars= (  top => util_top('Trunks - Edit Trunk',$who).util_top_menu('Trunks'),
	name => 'unnamed',cost=>1,max_count=>1,descr=>'',secret=>'0000',ip=>'127.0.0.1',allow=>get_rules($id,1),deny=>get_rules($id,0),
	templates=>html_select(db_query("select concat(trunk_type,'/',name),id from trunks_template")," name ='template_id' id='template_id' "));
	while(my ($key, $value) = each(%{$row})) {
                $vars{$key}=$value;
        }
        my $template_id=$vars{'template_id'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
 \$('#template_id').attr('value','$template_id')
  }
 )
";
	
	unless($cgi->param('r')){}else{#for group_edit return
	$vars{'return'}="<input type=hidden name=r value=1><input type=hidden name=i value=".$cgi->param('i').">";
	}
	print html_header;
	print util_template("templates/trunk_edit.tmpl",\%vars);
} else {
	my ($name,$cost,$max_count,$descr,$secret,$ip,$template_id,$priority,$add_ip)=($cgi->param('name'),$cgi->param('cost'),
        $cgi->param('max_count'),$cgi->param('descr'),$cgi->param('secret'),$cgi->param('ip'),$cgi->param('template_id'),
	$cgi->param('priority'),$cgi->param('add_ip'));

        my $trunk_type=db_query_one("select trunk_type from trunks_template where id=$template_id");

        db_query_exec("update trunks_trunk set name= ".db_quote($name).", cost=$cost,max_count=$max_count,
			descr=".db_quote($descr).",secret=".db_quote($secret).",ip='$ip',template_id=$template_id,
			priority=$priority,add_ip='$add_ip',
			trunk_type='$trunk_type' where id=$id");
        db_commit();
	
	db_query_exec("delete from trunks_rules where trunk_id=$id");
	

	foreach(("allow","deny")){
		my $pallow=$_;
		my $allow=0;
		if($pallow eq "allow"){$allow=1;};
	foreach(split(/\n/,$cgi->param($pallow))){
		my $prefix=$_;
		$prefix=~s/\s+//g;
		my $pos=index($prefix,'+');
		my $add_prefix='';
		if ($pos>0){
		 $add_prefix=substr($prefix,0,$pos);
		 $prefix=substr($prefix,$pos+1);
		}
		my $strip=index($prefix,'|');
		if ($strip <=0){$strip=0;}
		$prefix=~s/\|//;
		db_query_exec("insert into trunks_rules(ext_prefix,add_prefix,strip,trunk_id,allow)
			 values('$prefix','$add_prefix','$strip',$id,$allow)");
	}
	}#alow,deny
	db_commit();
	unless($cgi->param('r')){
		print html_redirect("Trunks.pl");
	}else{
		 print html_redirect("group_edit.pl?id=".$cgi->param('i'));
	}

}


