#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';

sub get_rules{
        my ($id,$rule)=(@_);
        my $rows=db_query_array("select 
        concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as prefix from trunks_agent_rules where agent_id=$id and allow=$rule");
        return join("\n",@{$rows});
}


unless($cgi->param('id')){
        print html_redirect("Agents.pl");
        exit;
}


my $id=$cgi->param('id');
my $count100="";
for(my $i=0;$i<100;$i++){
	$count100.="<option>$i</option>";
}

unless($cgi->param('max_count')){
my $error=$cgi->param("error");
unless($error){$error='';}else {$error=~s/_/ /g};

my %vars= (  top => util_top('Agents - Edit Agent',$who).util_top_menu('Agents'),error=>$error,
	descr => 'Agent',priority=>1,max_count=>5,name=>'Unnamed',prepaid=>0,credit=>0,deny=>get_rules($id,0),
	count100=>$count100,
	ips=>html_table(db_query("select concat('<a href=\"agent_ip_del.pl?aid=$id&id=',id,'\" >D</a> ') as action, INET_NTOA(ip) from 
			trunks_agent_ip where agent_id=$id order by INET_NTOA(ip)")),
	rules=>html_table(db_query("select concat('<a href=\"agent_rule_del.pl?aid=$id&id=',id,'\" >D</a>&nbsp;<a href=\"agent_rule_edit.pl?aid=$id&id=',id,'\" >E</a>') as action,name,
		case when rule_type=1 then
		 concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
 		    case when strip=0 then  ext_prefix else
		      concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
		     end
		    )
 		when rule_type=2 then
		 concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, from_n,'-',to_n)
		when rule_type=3 then
			concat('MULTIRULE ',
		(select count(*) from trunks_agent_rules as b where agent_id=$id and allow and b.parent=a.id), ' rule(s)')
		end as prefix,

		cost,concat(in_dial,'/',max_count) as counts from trunks_agent_rules as a where agent_id=$id and allow and parent is null order by prefix"))
);
	
	my $row=db_query_hash("select * from trunks_agent where id=$id");

        while(my ($key, $value) = each(%{$row})) {
                $vars{$key}=$value;
        }
	my $autopeer=$vars{'autopeer'};
	  my $type=$vars{'type'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
	\$('#autopeer').attr('value','$autopeer')
	\$('#name').attr('disabled','disabled');
  }
 )
";
	$vars{'select_groups'}=html_select(db_query("select descr,id from trunks_group a where (select 1 from trunks_agent2group b where b.agent_id=$id and b.group_id=a.id limit 1) is null")," name='group' id='s_group'" );
	$vars{'groups'}= html_table(db_query("select concat('<a href=\"#\" onclick=\"javascript:a2g_delete(',id,')\">D</a>'),descr from trunks_group a where (select 1 from trunks_agent2group b where b.agent_id=$id and b.group_id=a.id limit 1) is not null order by a.priority"));
	print html_header;
	print util_template("templates/agent_edit.tmpl",\%vars);
} else {
	my ($max_count,$descr,$emails,$prefix,$flags,$credit,$prepaid)=(
		$cgi->param('max_count'),$cgi->param('descr'),
	        $cgi->param('emails'),$cgi->param('prefix'),$cgi->param('flags'),$cgi->param('credit'),$cgi->param('prepaid'));
	my $autopeer=$cgi->param('autopeer');
	if($autopeer eq "0"){$autopeer='';};
	db_query_exec("insert into trunks_log(log) values(".db_quote("update trunks_agent set descr=".db_quote($descr).",
                emails=".db_quote($emails).",max_count=$max_count,prefix='$prefix',flags='$flags' ,
                autopeer='$autopeer'
                where id=$id").")");
	db_query_exec("update trunks_agent set descr=".db_quote($descr).",
		emails=".db_quote($emails).",max_count=$max_count,prefix='$prefix',flags='$flags' ,
		autopeer='$autopeer',credit='$credit',prepaid=$prepaid
		where id=$id");
	db_query_exec("delete from trunks_agent_rules where agent_id=$id and not allow");
	
        my $allow=0;
        foreach(split(/\n/,$cgi->param('deny'))){
                my $prefix=$_;
                $prefix=~s/\s+//g;
                my $pos=index($prefix,'+');
                my $add_prefix='';
                if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
                db_query_exec("insert into trunks_agent_rules(ext_prefix,add_prefix,strip,agent_id,allow)
                         values('$prefix','$add_prefix','$strip',$id,$allow)");
        }
	db_commit();
	print html_redirect("Agents.pl");

}
