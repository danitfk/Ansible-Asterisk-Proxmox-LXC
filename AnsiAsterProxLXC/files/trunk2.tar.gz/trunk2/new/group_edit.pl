#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;
use Data::Dumper;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';


sub get_rules{
        my ($id,$rule)=(@_);
        my $rows=db_query_array("select 
        concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as prefix from trunks_group_rules where group_id=$id and allow=$rule");
        return join("\n",@{$rows});
}



unless($cgi->param('id')){
        print html_redirect("Groups.pl");
        exit;
}


my $id=$cgi->param('id');
unless($cgi->param('descr')){
        my $row=db_query_hash("select * from trunks_group where id=$id");

	my %vars= (  top => util_top('Groups - Edit Group',$who).util_top_menu('Groups'),id=>$id,
	allow=>get_rules($id,1),deny=>get_rules($id,0));
	while(my ($key, $value) = each(%{$row})) {
                $vars{$key}=$value;
        }
        my $type=$vars{'type'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
 \$('#type').attr('value','$type')
  check_type();
  }
 )
";
	my $gtype=$row->{'type'};
        if ($gtype eq "1"){#BY_COST
                $gtype='cost,b.id';
        } elsif( $gtype eq 2){
                $gtype=' b.id ';
        } elsif( $gtype eq 3 ){
                $gtype=' priority,b.id ';
        } elsif( $gtype eq 4 ){
                $gtype=' acd desc,b.id';
        } elsif( $gtype eq 5 ){
                $gtype=' acd desc,priority,b.id';
        } elsif( $gtype eq 6 ){
                $gtype=' acd desc,cost,b.id';
        }
	my $type_param=$row->{'type_param'};

	my $advanced="";
	if($gtype=~m/acd/){
                $type_param=~s/[^0-9]//g;
                if(!($type_param=~m/[0-9]/)){$type_param=60;};
                my $acd_time=db_query_one("select substr(date_sub(now(),interval $type_param minute),1,16)");

                $advanced=",
                        FLOOR((select sum(billsec)/
                                  case when sum(case when billsec>0 then 0 else 1 end)>0
                                       then sum(case when billsec>0 then 0 else 1 end)
                                         else 1
                                  end
                        from trunks_cdr 
                                where trunk_id=b.id and stoptime > '$acd_time'
                        )/60*100)/100
                        as acd ";

        }

	$vars{'trunks'}=html_table(db_query("select 
		concat('<a href=\"trunk_edit.pl?r=g&i=$id&id=',b.id,'\" >E</a> <a href=\"group_trunk_del.pl?r=g&i=$id&id=',a.id,'\" >D</a> <a href=\"trunk_pause.pl?r=g&i=$id&id=',b.id,'\" >',case when paused then 'U' else 'P' end ,'</a>') as action,
        concat(trunk_type,'/',name),priority,descr,concat(in_dial,'/',max_count),
concat(case when paused then 'PAUSED ' else 
  ' ' 
  end,
  case when auto_pause_1 then ' Broken ' else ' ' end ,
  case when auto_pause_2 then ' A2 ' else ' ' end ,
  case when auto_pause_3 then ' A3 ' else ' ' end ) $advanced
  
 from trunks_trunk2group as a left join trunks_trunk as b on a.tid=b.id where a.gid=$id order by $gtype"));
	if($vars{'trunks'} eq ""){$vars{'trunks'}="<TR><TD>EMPTY</td></tr>";};
	$vars{'trunks_list'}=html_select(db_query("select name,id from trunks_trunk  where id not in (select tid from trunks_trunk2group where gid=$id) order by name","name=trunk id='trunk' ")," name='tid' ");	
	print html_header;
	print util_template("templates/group_edit.tmpl",\%vars);

} else {
	my ($max_count,$descr,$priority,$type,$type_param)=($cgi->param('max_count'),$cgi->param('descr'),$cgi->param('priority'),
        $cgi->param('type'),$cgi->param('type_param'));

        db_query_exec("update trunks_group set priority=$priority,max_count=$max_count,
			descr=".db_quote($descr).",type=$type,type_param='$type_param' where id=$id");
        db_commit();
	
	db_query_exec("delete from trunks_group_rules where group_id=$id");
	

#	print html_header."<pre>";
	foreach(("allow","deny")){
		my $pallow=$_;
		my $allow=0;
#		print $_."-".$cgi->param($pallow)."\n";
		if($pallow eq "allow"){$allow=1;};
	foreach(split(/\n/,$cgi->param($pallow))){
		my $prefix=$_;
		$prefix=~s/\s+//g;
		my $pos=index($prefix,'+');
		my $add_prefix='';
		if ($pos>0){
		 $add_prefix=substr($prefix,0,$pos);
		 $prefix=substr($prefix,$pos+1);
		}
		my $strip=index($prefix,'|');
		if ($strip <=0){$strip=0;}
		$prefix=~s/\|//;
#		print"insert into trunks_group_rules(ext_prefix,add_prefix,strip,group_id,allow)
#                         values('$prefix','$add_prefix','$strip',$id,$allow)\n";
		db_query_exec("insert into trunks_group_rules(ext_prefix,add_prefix,strip,group_id,allow)
			 values('$prefix','$add_prefix','$strip',$id,$allow)");
	}
	}#alow,deny
	db_commit();
	print html_redirect("Groups.pl");

}


