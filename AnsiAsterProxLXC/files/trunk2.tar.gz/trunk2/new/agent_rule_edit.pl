#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';

sub get_rules{
        my ($id,$rule)=(@_);
        my $rows=db_query_array("select 
        concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as prefix from trunks_agent_rules where agent_id=$id and allow=$rule");
        return join("\n",@{$rows});
}


unless($cgi->param('id')){
        print html_redirect("Agents.pl");
        exit;
}


my $id=$cgi->param('id');
my $count100="";
for(my $i=0;$i<100;$i++){
	$count100.="<option>$i</option>";
}

unless($cgi->param('max_count')){
my $error=$cgi->param("error");
unless($error){$error='';}else {$error=~s/_/ /g};

my %vars= (  top => util_top('Agents - Edit Rule',$who).util_top_menu('Agents'),error=>$error,
	priority=>1,max_count=>5,name=>'Unnamed',aid=>$cgi->param("aid"),id=>$id,
	count100=>$count100,
);
	
	my $row=db_query_hash("select concat(case when add_prefix!='' then concat(add_prefix,'+') else '' end, 
                case when strip=0 then  ext_prefix else
                        concat(substr(ext_prefix,1,strip),'|',substr(ext_prefix,strip+1))
                 end
            ) as rule,name,cost,max_count,rule_type,from_n,to_n,add_prefix from trunks_agent_rules where id=$id");

        while(my ($key, $value) = each(%{$row})) {
                $vars{$key}=$value;
        }
	my $autopeer=$vars{'autopeer'};
	  my $type=$vars{'type'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
	//
  }
 )
";
	print html_header;
	print util_template("templates/agent_rule_edit.tmpl",\%vars);
} else {
	my ($max_count,$name,$cost)=($cgi->param("max_count"), $cgi->param("name"), $cgi->param("cost"));
	my $rule=$cgi->param("rule");
	my $rule_type=$cgi->param("rule_type");
	my $from_n=$cgi->param("from_n");
	my $to_n=$cgi->param("to_n");
	my $add_prefix=$cgi->param("add_prefix");
        if($rule_type eq "1"){
		my $prefix=$rule;
	        $prefix=~s/\s+//g;
	        my $pos=index($prefix,'+');
	        my $add_prefix='';
	        if ($pos>0){
	                 $add_prefix=substr($prefix,0,$pos);
	                 $prefix=substr($prefix,$pos+1);
	        }
        	my $strip=index($prefix,'|');
	        if ($strip <=0){$strip=0;}
	        $prefix=~s/\|//;
	        db_query_exec("update trunks_agent_rules set rule_type=1,
				ext_prefix='$prefix',add_prefix='$add_prefix',strip='$strip',
				cost=$cost,max_count=$max_count,name=".db_quote($name)." where id=$id");
		db_commit();
        }elsif($rule_type eq "2"){
		my $aid=$cgi->param('aid');
		unless($from_n){ print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid");exit ;};
		$from_n=~s/[^0-9]//g;	$to_n=~s/[^0-9]//g;
		if($from_n eq ""){print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid");exit ;};
		if(length($from_n) != length($to_n)){ print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid");exit ;};
		$from_n=int($from_n);
		$to_n=int($to_n);
		if($to_n<=$from_n){
			print html_redirect("agent_rule_edit.pl?id=$id&aid=$aid");exit ;
		}
		my $sql="update trunks_agent_rules set 
					rule_type=2,
					from_n='$from_n',to_n='$to_n',
					add_prefix='$add_prefix',
			strip=0,ext_prefix='$from_n',cost=$cost,max_count=$max_count,name=".db_quote($name)." where id=$id";
		db_query($sql);
		db_commit();
	}
	print html_redirect("agent_edit.pl?id=".$cgi->param('aid'));
}
