#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");


#start block
my $mname="";

unless($cgi->param('name')){
my %vars= (  top => util_top('Templates - Add New',$who).util_top_menu('Templates'),name=>'Unnamed',value=>"type=friend\ndisallow=all\nallow=g729\ncontext=trunks2\nhost=dynamic");
	print html_header;
	$vars{'trunk_type'}="<select name='trunk_type'><option>SIP</option><option>IAX2</option>
<option>ZAP</option><option>DAHDI</option>
<option>H323</option><option>OH323</option><option>OOH323</option><option>Datacard</option><option>Dongle</option><option>Local</option>
</select>";
	print util_template("templates/template_edit.tmpl",\%vars);

}else{
	db_query_exec("insert into  trunks_template (name,value,trunk_type) values(".db_quote($cgi->param('name')).",
		".db_quote($cgi->param("value")).",".db_quote($cgi->param("trunk_type")).");");
	db_commit();
	print html_redirect("Templates.pl");
}
