#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");


#start block
my $mname="";

unless($cgi->param('id')){

}else{
	db_query_exec("delete from trunks_trunk where id=".$cgi->param('id'));
	db_query_exec("delete from trunks_rules where trunk_id=".$cgi->param('id'));
	db_commit();
}
print html_redirect("Trunks.pl");
