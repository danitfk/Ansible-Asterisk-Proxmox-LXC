#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $id= $cgi->param('id');
unless($id) {} else {
db_query_exec("update  trunks_agent set paused=not paused where id=$id");
db_commit();
}

#start block

unless($cgi->param('r')){
                print html_redirect("Agents.pl");
        }else{
                print html_redirect("group_edit.pl?id=".$cgi->param('i'));
        }
