cd /tmp/
nohup /var/www/html/trunk2/safe_server.sh & 
