#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");


#start block
my $mname="";
print html_header;
my $c=db_query_one ("select sum(auto_pause_1) from trunks_trunk where auto_pause_1 is not null");
#my $broken=qq{<input type="button" onclick="javascript:m_submit('trunk_unpause_broken.pl',' UnPause Broken')" value="UnPause Broken">};
my $broken="";
#if ($c == 0){
# $broken=qq{<input type="button" onclick="javascript:m_submit('trunk_pause_broken.pl',' Pause Broken')" value="Pause Broken">};
#};
my $pauses='';
#for (my $i=1;$i<10;$i++){
# my $count=db_query_one ("select sum(paused) from trunks_trunk where name like 'GSM $i%' and substr(name,7,1) =' ' ");
# if ($count){
#  $pauses.="<input type='button' onclick=\"javascript:m_submit1('trunk_pause_set.pl',' UnPause ${i}X','$i','false')\" value='UnPause ${i}X'>";
# } 
#}

my %vars= (  top => util_top('Groups',$who).util_top_menu('Groups'),tab=>html_table(db_query("select 
   concat('<a href=\"group_edit.pl?id=',id,'\" >E</a> <a href=\"group_del.pl?id=',id,'\" >D</a> <a href=\"group_pause.pl?id=',id,'\" >',case when paused then 'U' else 'P' end ,'</a>') as action,
	priority,descr,concat(in_dial,'/',max_count),c,ok,concat(sum div 60,':',sum %60 ), case when sum=0 then 0 else concat(( sum div ok) div 60,':',(sum div ok ) %60 ) end ,
 concat(case when paused then 'PAUSED ' else 
  ' ' 
  end,
  case when auto_pause_1 then ' Broken ' else ' ' end ,
  case when auto_pause_2 then ' A2 ' else ' ' end ,
  case when auto_pause_3 then ' A3 ' else ' ' end ),
  case when count is null then '-' when success=0 then 0  else
         concat(b.billsec/success div 60,':',round(b.billsec/success) %60 ) 
  end,
  case when count is null then '-' when success=0 then 0  else truncate(success/count*100,2) end
  from trunks_group as a left join 
  ( select group_id,sum(billsec) as billsec,count(*) as count,sum(case when billsec>0 then 1 else 0 end) as success from trunks_cdr where stoptime>date_sub(CURRENT_TIMESTAMP, interval 15 minute) group by group_id ) as b on b.group_id=a.id
   order by priority,descr")),
 broken =>$broken,pauses=>$pauses
);

print util_template("templates/Groups.tmpl",\%vars);
