#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;
use JSON;
my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}

my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");


#start block
my $mname="";
#print html_header;

#print 1;
my $sql="
select starttime, case when answer_time >'2001-01-01' then TIME_FORMAT(answer_time,'\%H:\%i:\%S') else '-' end
 ,case when disconnecttime>'2001-01-01' then TIME_FORMAT(disconnecttime,'\%H:\%i:\%S') else '-' end
 ,dst,dst_changed,cid,
 case when answer_time >'2001-01-01' then 
  case when disconnecttime  >'2001-01-01' then 
	 SEC_TO_TIME( timestampdiff(second,answer_time,disconnecttime))
     else
	  SEC_TO_TIME( timestampdiff(second,answer_time,now()) )
   end

 else '-' end
 ,INET_NTOA(a.ip),INET_NTOA(a.server_ip),ag.name,t.name from trunks_active a left join trunks_agent ag on ag.id=a.agent_id left join trunks_trunk t on t.id=a.trunk_id order by case when  disconnecttime <'2001-01-01' then 0 
                          else 2 end  ,starttime desc limit 30";

my $res=db_query($sql);
print javascript_header($cgi);
print JSON->new->encode([$res]);



