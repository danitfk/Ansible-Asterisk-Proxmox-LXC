#!/bin/bash
cd /var/www/html/trunk2/
while /bin/true
do
port=`cat port.opt`
if test $port -ge 5000
then
port=4000
else
port=$[ $port + 1 ]
fi;
if test $port  -le 4000
then
 port=4000
fi;
echo $port >port.opt
./create_config.sh
echo "new start $port





">>/var/log/trunk2.log
#echo "update trunks_trunk set in_dial=0,last_checked=now() ;
#update trunks_group set in_dial=0,last_checked=now() ;
#update trunks_agent set in_dial=0;
#update trunks_agent_rules set in_dial=0;
#"|/usr/bin/mysql asterisk -u trunk2 --password=mtest -s

./server.pl $port >>/var/log/trunk2.log 2>>/var/log/trunk2.log
new_port=`cat port.opt`
if test "$new_port" != "$port"
then
 echo " looks like we not primary server, exiting"
fi;
done;
