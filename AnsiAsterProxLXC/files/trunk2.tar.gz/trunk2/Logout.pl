#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;
use CGI ':standard';
use CGI::Carp qw(fatalsToBrowser);


my $cgi=new CGI;
my $login=$cgi->param('login');

#check if session ok. if nto redirect to login
my $ses=session_check($cgi);

$ses->delete();

print html_redirect("index.pl");
