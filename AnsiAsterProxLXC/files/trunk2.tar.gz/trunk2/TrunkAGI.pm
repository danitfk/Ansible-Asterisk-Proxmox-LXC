package TrunkAGI;

use strict;
use warnings;
use diagnostics;
use Data::Dumper;
use Asterisk::FastAGI;
our @ISA = qw( Asterisk::FastAGI);
use Switch;

use mlib::db;

#since 2.9 config in database
my %config;

# config last read at this time. will re-read every 30 sec.
my $last_config_read=0;

sub version{
	print "Version: 2.12.5\n";
}

my $server_ip=`/sbin/ifconfig |grep inet|head -n 1|cut -f 2 -d:|cut -f 1 -d B`;
$server_ip=~s/\s//g;  

my $npaused="((not paused )and in_dial <max_count  and (not auto_pause_1) and (not auto_pause_2) and (not auto_pause_3) )";

  sub fastagi_handler {
    my $self = shift;
    my $dialed="";
  my $dst = $self->param('dst');
  my $cid = $self->input('callerid');
  my $unique = $self->agi->get_variable('UNIQUEID');
  
  my $ip=$self->agi->get_full_variable('${ip}');
  unless($ip){
	$ip="";
  };
	if(length($ip)<2){
	  $ip=$self->agi->get_full_variable('${SIPCHANINFO(recvip)}${IAXPEER(CURRENTCHANNEL)}');
	}
  unless($ip){
		$self->tlog(0,"no IP on incoming , hangup");
		return;	
  } 
  
  my $do=1;my $c=0;
  my $prefix=$self->input('uniqueid').' '.$self->input('extension')." " ;

  $self->tlog(0,"$prefix access from ip $ip ($dst/$cid)");
  $self->{server}{prefix}=$prefix;

  $self->config_read();
  my $d_options=$config{d_options_default};
  my $d_opt=$d_options;#$self->agi->get_variable("DIAL_OPT");
  my $con=$self->db_check();
  db_rollback_($con);
  $self->{server}{agent_id}=0;  $self->{server}{rule_id}=0;
  $self->{server}{trunk_id}=0;  $self->{server}{group_id}=0;
  $self->{server}{unique}=$unique;
  unless ($d_opt){
	#$self->tlog(4,"$prefix NO dial opt, assuming $d_options");
  } else {
  	$self->tlog(0,"$prefix dial opt $d_opt");
  	$d_options=$d_opt;
  }

  $self->set_ip($ip,0,'',0,'');
# incoming sequence  
  $self->tlog(4,"$prefix trying get lock");
  my $lock=db_query_one_("select GET_LOCK('trunks_incoming',100)",$con);
  unless($lock){
	$self->tlog(0,"$prefix can't get lock incoming");
	do_congestion($self,$con);
	return;
  }
  $self->tlog(4,"$prefix lock ok");

  my $set=db_query_(" 
		select a.id as aid,name,INET_NTOA(ip) as ip ,flags,prefix, (max_count>in_dial) as in_dial,
			case when prepaid then credit else 1000 end 
		from trunks_agent as a left join trunks_agent_ip as b on a.id=b.agent_id where ip=INET_ATON('$ip') and not paused order by a.id limit 1",$con);
  
  unless(@{$set}[0]){
	$self->tlog(0,"$prefix access from $ip, not found ");
	do_congestion($self,$con);
	return;
  }
  
  my $rule_id=0;
  my ($agent_id,$agent_name,$agent_ip,$dial_flags,$dial_prefix,$f_in_dial,$agent_credit)=@{@{$set}[0]};
  if ($agent_credit<=0){
                $self->tlog(1,"$prefix access forbidden on no credit $agent_credit ");
                db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
                do_congestion($self,$con);
                return;
  }
  $prefix.=" $agent_name $agent_ip ";           $self->{server}{prefix}=$prefix;
  if($f_in_dial){
#	  $self->tlog(0,"$prefix Flags $dial_flags, prefix $dial_prefix ");
	  if(!($dial_flags eq "")){
		$d_options=$dial_flags;
	  }
	   $self->tlog(0,"$prefix Flags  $d_options prefix $dial_prefix ");
  }else{
          $self->tlog(0,"$prefix access from $agent_name,$agent_ip,$dial_flags,$dial_prefix - max_count reached");
	  db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
	  do_congestion($self,$con);
	  return;
  };
   

  my $dstStripped="";
  if (!($prefix eq "")){
	if ($dst =~ m/^$dial_prefix/){
		$dst=~s/^$dial_prefix//;
		$dstStripped=$dst;
		$self->tlog(1,"$prefix removed $dial_prefix, new number $dst");
	}else{
		$self->tlog(0,"$prefix access forbidden on no prefix");
		db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
		do_congestion($self,$con);
	        return;
	}
  }
  ####################################### Recently Dialed Delay Rule ##### vijay add billsec <'10' part ### 
  my $sql_limit ="select 1 from trunks_cdr where number='$dst' and billsec <'10' and stoptime>date_sub(now(),interval ".$config{recently_dialled_delay}.") limit 1";
  unless(db_query_one_($sql_limit,$con)){}else{
                $self->tlog(1,"$prefix access forbidden on $config{recently_dialled_delay} rule ");
                db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
                do_congestion($self,$con);
                return;
  }
  if($cid eq "444unknown"){}else{
   ### same for cid ######################################################
          $sql_limit ="select 1 from cdr where src='$cid' and calldate>date_sub(now(),interval ".$config{recently_cid_delay}.") limit 1";
           
	unless(db_query_one_($sql_limit,$con)){}else{
                $self->tlog(1,"$prefix access forbidden on recently_cid_delay $config{recently_cid_delay} rule ");
                db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
                do_congestion($self,$con);
                return;
   }
   ###################################### add prefix if we have call with this cid #################
   if(!($config{same_cli_prefix} eq "")){
           $self->agi->set_variable("GROUP(CID)","$cid");
           my $res=$self->agi->get_full_variable('${GROUP_COUNT('.$cid.'@CID)}');
           unless($res){
			db_query_("select RELEASE_LOCK('trunks_incoming')",$con);
		return $do;}
           if($res>1){
                $self->tlog(0,"$prefix adding prefix $config{same_cli_prefix} becuase we have cid $cid $res times");
		$dst=$config{same_cli_prefix}.$dst;
           }
   }
  }####cid not unknown
  ###############################################AGENT LOCK#########################
  $self->tlog(4,"$prefix +1 for $agent_name($agent_id)");
  db_query_exec_("update trunks_agent set in_dial=in_dial+1 where id=$agent_id",$con);
  db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($agent_id,3,INET_ATON('$server_ip'),$unique)",$con);
  db_commit_($con);
  $self->{server}{agent_id}=$agent_id;
  db_query_("select RELEASE_LOCK('trunks_incoming')",$con);



my $redo=1;
while($redo){# do redo in case of whitelist call limiting 
  #########################################BLACKLIST################################# 
  # blacklist
  $dst=$self->black_list($dst);
	  $redo=0;
#  mysql_query_("select RELEASE_LOCK('trunks_incoming')",$con);
# do release auto
  $lock=db_query_one_("select GET_LOCK('trunks_agent_$agent_id',100)",$con);
  unless($lock){
        $self->tlog(0,"$prefix can't get lock agent");
        do_congestion($self,$con);
	return;
  }
  #####################################################check striped number in rules#####
  my $sql="select distinct id,name,concat(add_prefix,substr('$dst',strip+1)) as  new_number, cost,in_dial>=max_count,
		ext_prefix,parent
                                        from trunks_agent_rules 
                                        where  agent_id=$agent_id and allow=1  and  
					 (    ( (rule_type= 1 ) and ('$dst' rlike concat('^',ext_prefix) ) ) or
					      ( (rule_type= 2 ) and (
	convert(substr('$dst',1,length(from_n)),UNSIGNED)>=from_n  and 
		convert(substr('$dst',1,length(from_n)) ,UNSIGNED) <=to_n) )	)
                                    order by length(ext_prefix) desc limit 1";
  my $sql_multirule="select id,name,cost,in_dial>=max_count 
			from trunks_agent_rules where  agent_id=$agent_id and allow=1  and id=";
#  $self->tlog(0,"$prefix  $sql");
  my ($a_rule_id,$rule_name,$new_number,$rate_value,$f_in_use,$ext_prefix,$parent);
  $self->{server}{cost}=0;
  $self->{server}{agent_id}=$agent_id;
  $a_rule_id=-1;
#        $self->tlog(4,"$prefix $sql");
        my $set2=db_query_($sql,$con);
        for my $j  (@{$set2}){
                        ($a_rule_id,$rule_name,$new_number,$rate_value,$f_in_use,$ext_prefix,$parent)=@{$j};
			unless($parent){}else{# we have multirule, so need get info form parent
				my $set_m=db_query_($sql_multirule."$parent",$con);
				$a_rule_id=0;
				for my $row_m ( @{$set_m} ){
					($a_rule_id,$rule_name,$rate_value,$f_in_use,$parent)=@{$row_m};
				}
				if($a_rule_id == 0){
					next;
				}
				$self->tlog(0,"$prefix mrule $a_rule_id,$rule_name/$ext_prefix, num=$new_number,$rate_value,$f_in_use");
			}
			if($f_in_use){
				$self->tlog(0,"$prefix max count for $rule_name reached");
			        do_congestion($self,$con);
			        return;
			}
                        #get new prefix in deny?
                        my $check=db_query_one_("select ext_prefix 
                                                        from trunks_agent_rules
                                                        where agent_id=$agent_id and allow=0 and '$dst' rlike concat('^',ext_prefix)
                                                 limit 1",$con);
                        unless($check){
				$self->tlog(1,"$prefix incoming rule  $rule_name, number now $new_number");
				$rule_id=$a_rule_id;
				$dst=$new_number;
				$self->tlog(4,"$prefix +1 for $rule_name($rule_id);");
				db_query_exec_("update trunks_agent_rules set in_dial=in_dial+1 where  id=$a_rule_id;",$con);
				db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($a_rule_id,4,INET_ATON('$server_ip'),$unique)",$con);
				db_commit_($con);
				$self->{server}{rule_id}=$rule_id;
				$self->{server}{cost}=$rate_value;
			}else{
                                $self->tlog(1,"$prefix incming rule  $rule_name blocked by  deny rule $check");
			         do_congestion($self,$con);
			         return;
                        }
        }
 if($a_rule_id==-1 ){
                do_congestion($self,$con);
		$self->tlog(1,"$prefix no rule for $dst,congestion");
                return;
 }
 $self->set_ip($ip,$agent_name,$rule_name,$rate_value,$dstStripped);
 db_query_one_("select RELEASE_LOCK('trunks_agent_$agent_id')",$con);
  
 #outgoing cdrs
  my %dialled_trunks=();#for test we already dialled.
 my $cdr_limit=$config{cdr_limit};
if($cdr_limit>0){
  $set=db_query_("
		select b.id ,group_id, name , in_dial ,paused,dialled,max_count,b.trunk_type,b.cost,b.max_call_time, 0 as  from_cdr
		from (select dialled,trunk_id,group_id,max(stoptime) as max_time from 
			trunks_cdr as a
			where a.billsec>0 and number='$dst' and stoptime>DATE_SUB(NOW(),INTERVAL ".$config{cdr_interval}.") 
		     group by dialled , trunk_id,group_id
			order by max_time limit $cdr_limit
		 ) as a  left join trunks_trunk as b  on a.trunk_id=b.id   where $npaused
		 order by max_time desc limit $cdr_limit
		",$con);
  for my $i (@{$set}){
   if ($do!=1 ) {next;}
   my ($id , $gid,$trunk_name ,  $in_dial ,$paused,$new_number,$max_count,$trunk_type,$cost,$max_call_time)=@{$i};
   if (exists  $dialled_trunks{$id}){
	if($dialled_trunks{$id} eq $new_number){
	     next;
	}
   };
   $dialled_trunks{$id}=$new_number;#set this trunk as dialled
   if(skip_trunk_used ($con,$id,$gid)){next;}
   $c=$c+1;
   $do=$self->do_dial($con,$prefix, $do,
		$trunk_type,$trunk_name, $new_number, 	 	$config{maxtime},$d_options,
		$id,$gid,$unique,$ip,$agent_name,$rule_name,$rate_value,	$dst,$dstStripped,$cost,$c,"",$max_call_time);

  }#end for <cdr>
  $self->tlog(4,"$prefix cdr ends..");
}# if cdr_limit >0

  $set=db_query_("
	select id,type,descr,type_param from trunks_group a join trunks_agent2group as b on b.agent_id=$agent_id and b.group_id=a.id
		where $npaused order by priority,rand()
                ",$con);
  my $try_left=$config{try_limit};
  my $any_exist=0;
  for my $i (@{$set}){
	$any_exist=1;
	if ($do!=1 ) {next;}
	my ($gid , $gtype,$descr,$type_param)=@{$i};
#a	$self->tlog(0,"$prefix group $descr ");
     	my $new_dst=db_query_one_("
		select concat(add_prefix,substr('$dst',strip+1)) as  new_number 
				from 		trunks_group_rules
				where group_id=$gid and allow=1 and '$dst' rlike concat('^',ext_prefix)
		order by length(ext_prefix) desc limit 1",$con);
	unless($new_dst){
		$self->tlog(0,"$prefix nothing found in group $gid/$descr for this num");
		next;
	}

	$self->tlog(0,"$prefix group $descr match,new number is $new_dst "); 
	my $check=db_query_one_("select ext_prefix,add_prefix, strip
					 from trunks_group_rules 
					where group_id=$gid and allow=0 and '$dst' rlike concat('^',ext_prefix)
				 limit 1",$con);
	unless($check){}else{ $self->tlog(4,"$prefix group $descr deny by $check.."); next;	}
	$gtype=$self->get_g_type($gtype); unless($gtype){next;}
	
	my $advanced=",0 as acd";
	my $advanced_tab="";
	if($gtype=~m/acd/){
		$type_param=~s/[^0-9]//g;
		if(!($type_param=~m/[0-9]/)){$type_param=60;};
		my $acd_time=db_query_one("select substr(date_sub(now(),interval $type_param minute),1,16)",$con);

		
                $advanced=",
                        case when info.count is null then '-' when info.success=0 then 0  else
         concat(info.billsec/info.success div 60,':',round(info.billsec/info.success) %60 ) 
  end
                        as acd ";
                $advanced_tab=" left join
             ( select trunk_id,sum(billsec) as billsec,count(*) as count,sum(case when billsec>0 then 1 else 0 end) as success from trunks_cdr where stoptime > '$acd_time' group by trunk_id ) as info on info.trunk_id=a.id ";

	}
	my $sql="select distinct  a.id , name,concat(add_prefix,substr('$new_dst',strip+1)) as  new_number,
                                                trunk_type,cost $advanced, max_call_time
                                from trunks_trunk as a join trunks_trunk2group as tg on tg.tid=a.id and gid=$gid
                                              join trunks_rules as b on a.id=b.trunk_id $advanced_tab
                                        where  $npaused and  '$new_dst' rlike concat('^',ext_prefix)
                                    order by $gtype limit $try_left";

#	$self->tlog(4,"$prefix $sql");
	my $set2=db_query_($sql,$con);
	for my $j  (@{$set2}){
			if ($do!=1 ) {next;}
			my ($id,$trunk_name,$new_number,$trunk_type,$cost,$acd,$max_call_time)=@{$j};
			$self->tlog(4,"$prefix checking G=$gid t=$id,$trunk_name,$new_number,$trunk_type,$cost,$acd,$max_call_time ");
			#get new prefix in deny?
			
			my $QUERY="select ext_prefix from trunks_rules where trunk_id=$id and allow=0 and '$new_dst' rlike concat('^',ext_prefix) limit 1";
			#$self->tlog(4,"$prefix  QUERY=$QUERY");
			$check=db_query_one_("$QUERY",$con);
		        unless($check){}else{
                		$self->tlog(4,"$prefix trunk  $trunk_name blocked by  deny rule $check");
		                next;
 		        }
			# looks like we can try this trunk.
			

			if (exists  $dialled_trunks{$id}){
			        if($dialled_trunks{$id} eq $new_number){
				     $self->tlog(4,"$prefix we already tried $new_number @ $id");
		        	     next;
		        	}
			};
			$dialled_trunks{$id}=$new_number;#set this trunk as dialled
			if(skip_trunk_used ($con,$id,$gid)){next;}
			$c=$c+1;$try_left--;
			if($try_left<=0){$do=0;
				$self->tlog(4,"$prefix  try_left=0");
			};
#   			$self->tlog(0,"$prefix trying trunk $trunk_name of group $descr /attempt $c");
		        $do=$self->do_dial($con,$prefix, $do,  
		               $trunk_type,$trunk_name, $new_number,           $config{maxtime},$d_options,
		               $id,$gid,$unique,$ip,$agent_name,$rule_name,$rate_value,        $dst,$dstStripped,$cost,
				$c,"group $descr /attempt $c",$max_call_time
				);
					
	}#for
	if(!$any_exist){
			$self->tlog(4,"$prefix  no rules found for $dst");
	}

  }
  if($do==-5){#redo all again becuas of stop call on whitelist limit
	 $self->tlog(0,"$prefix we do whitelist limit, re-create. dialopts=$d_options");
	 $self->agi->exec('Dial', "\"Local/s\@trunks_wait,".$config{redial_delay}.",m()\"");
	 $d_options=~s/r//;
	 $d_options.='m()';
	 $dst=$self->{server}{whitelist_before};
	 $self->{server}{whitelist}=0;
	 $redo=1; 
	 $do=1;
	 unuse_agent($self,$con,$prefix,0,# not otuch agent lock, we will nto renew it yet, only clear rule lock
                                $self->{server}{rule_id},$self->{server}{unique});
  }elsif($do==-6){
	 $self->tlog(0,"$prefix we do blacklist limit, re-create. dialopts=$d_options");
         $self->agi->exec('Dial', "\"Local/s\@trunks_wait,".$config{redial_delay}.",m()\"");
         $d_options=~s/r//;
         $d_options.='m()';
         $dst=$self->{server}{blacklist_before};
         $self->{server}{blacklist}=0;
         $redo=1;
         $do=1;
         unuse_agent($self,$con,$prefix,0,# not otuch agent lock, we will nto renew it yet, only clear rule lock
                                $self->{server}{rule_id},$self->{server}{unique});
  }
}#while redo
 do_congestion($self,$con);
}

 sub do_congestion{###############do congestion
    my ($self,$con)=@_;
	 $con=$self->db_check();
	
	 my $prefix=$self->{server}{prefix};
	 if($self->{server}{agent_id}+$self->{server}{rule_id}>0){
		unuse_agent($self,$con,$prefix,$self->{server}{agent_id},
				$self->{server}{rule_id},$self->{server}{unique});
	 }
	 if($self->{server}{trunk_id}){
		unuse_trunk($self,$con,$prefix,$self->{server}{trunk_id},$self->{server}{group_id},0,0,$self->{server}{unique});	
	 }
	 db_query_one_("select GET_LOCK('trunks_end',1)",$con);  
	 db_query_one_("select RELEASE_LOCK('trunks_end')",$con);
	 $self->{server}{prefix}='';
#	 $con->disconnect();

	 $self->agi->exec('Congestion','2');
 }
 sub set_ip{
    my ($self,$ip,$agent,$name,$cost,$dst_stripped)=@_;
    unless($ip){
    $ip=$self->agi->get_full_variable('${ip}');  
    unless($ip){
        $ip="";
    };
    if(length($ip)<2){
          $ip=$self->agi->get_full_variable('${SIPCHANINFO(recvip)}${IAXPEER(CURRENTCHANNEL)}');
    }
    unless($ip){
                $self->tlog(0,"no IP on incoming , hangup");
    }       
    }
    $self->{server}{ip}=$ip;
    $self->agi->exec('Set','CDR(userfield)='.$ip);
    $self->agi->exec('Set','CDR(ip)='.$ip);
    $self->agi->exec('Set','CDR(rate_profile)='.$agent);
    $self->agi->exec('Set',"CDR(rate_name)=$name");
    $self->agi->exec('Set',"CDR(rate_value)=$cost");	
    $self->agi->exec('Set',"CDR(dstStripped)=$dst_stripped");
    
 }


 sub do_dial{
   my ($self,$con,$prefix,$do,$trunk_type,$trunk_name,$new_number,$maxtime,$d_options,$id,$gid,$unique,$ip,$agent_name,$rule_name,$rate_value,$dst,$dstStripped,$cost,$c,$info,$max_call_time)=(@_);
   $con=$self->db_check();
   my $res;
   if($config{same_dest_disallow}){
	   $self->agi->set_variable("GROUP(${id})","$new_number");
	   $res=$self->agi->get_full_variable('${GROUP_COUNT('.$new_number.'@'.$id.')}');
	   unless($res){return $do;}
	   if($res>1){
		$self->tlog(0,"$prefix skippping becuase we already have call to $new_number on trunk $trunk_name");
		return $do;
	   }
   }
   $self->tlog(0,"$prefix trying trunk $trunk_name do=$do $info");
   my $param=""; $res="";
   $param="b(trunks2^sh^1)U(trunks2_answer)";

   my $success_time=$config{add_to_success_after_min};
   if($config{add_to_success_after_max}>$config{add_to_success_after_min}){
	$success_time+=int(rand($config{add_to_success_after_max}-$config{add_to_success_after_min}+1));
   };
   if($self->{server}{blacklist}){
	if($config{do_blacklist_hold}>0){
		$self->tlog(0,"$prefix      limiting to  ".$config{do_blacklist_hold}." seconds (blacklist)");
		if(($max_call_time ==0) || ($max_call_time > $config{do_blacklist_hold})){
			$max_call_time=$config{do_blacklist_hold}; }
	}
   }elsif($self->{server}{whitelist}){# was new number, limit call to X second(for redial";
	if($config{do_success_hold}){
	        $self->tlog(0,"$prefix      limiting to $success_time seconds");
		if(($max_call_time ==0) ||($max_call_time > $success_time)){
			$max_call_time=$success_time;
		}
	}
   }
   if($max_call_time > 0 ){$param.="S($max_call_time)";}
   if (($trunk_type eq 'OOH323') || ($trunk_type eq 'H323') ){
     $param="$trunk_type/$new_number\@$trunk_name,$maxtime,$d_options$param";
   }elsif($trunk_type eq 'Local'){
	$self->tlog(0,"$prefix      get local channel");
	$param="$trunk_type/$new_number\@$trunk_name/n,$maxtime,$d_options$param";
   }else{
        $param="$trunk_type/$trunk_name/$new_number,$maxtime,$d_options$param";
   }    

   $self->tlog(0,"$prefix Dial $param  :attempt $c");
   use_trunk($self,$con,$prefix,$id,$gid,$unique);
   $self->start_active($dst,$new_number,$id);
   $res=$self->agi->exec('Dial', "\"$param\"");
   $con=$self->db_check();
   $res=$self->agi->get_variable('DIALSTATUS');
   unless($res){
              $self->tlog(0,"$prefix looks like we loose channel, trying again");
              $res=$self->agi->get_variable('DIALSTATUS');
   }    
   unless($res){        
          unuse_trunk($self,$con,$prefix,$id,$gid,0,0,$unique);
          $do=0;
          my $rec=$self->agi->exec('ResetCDR','w');
          $self->set_ip($ip,$agent_name,$rule_name,$rate_value,$dstStripped);
   }else {
        if (($res eq  'ANSWERED') ||($res eq 'CANCEL')||('ANSWER' eq $res)) { 
		$do=0;
                my $time=$self->agi->get_variable('ANSWEREDTIME');
                unless($time){$time=0;}
                #hack for retest TIME
                if (!($time=~m/^\d+$/)){
                        $self->tlog(1,"$prefix we have time not numeric. have to requery");
                        $time=$self->agi->get_variable('ANSWEREDTIME');
                }
                if ($time eq ""){$time=0;}
		if($time>0){
#		    $self->tlog(4,"$prefix  {server whitelist } ".$self->{server}{whitelist}." ".$add_to_success_after_min." ".$time);			
		   if(($self->{server}{blacklist})&&($time>$config{remove_from_blacklist_after})){
				$self->tlog(4,"$prefix removing from blacklist for id ".$self->{server}{blacklist_id});
				db_query_exec_("delete from blocklist where id=".$self->{server}{blacklist_id},$con);
		   }
		   if(($self->{server}{blacklist})&&($time==$config{do_blacklist_hold})){#do hold ^redial
				$self->tlog(4,"$prefix dooing hold(blacklist)");
				$do=-6;
        	                $self->agi->exec('ResetCDR','w');
                	        $self->set_ip($ip,$agent_name,$rule_name,$rate_value,$dstStripped);
		   }
             	   if(($self->{server}{whitelist})&&($time>=$config{add_to_success_after_min})){
                      #was new number and was limited/stoped
                      my $dst=db_quote($self->{server}{whitelist_before});
                      $self->tlog(4,"$prefix adding to WHITELIST $dst");
                      db_query_exec_("insert into ".$config{success_table}."(number) select substr($dst,-10) from ( select 1 as a)as a where (select 1 from ".$config{success_table}." where number=substr($dst,-10) limit 1)  is null ",$con);
                   };
		};
		my $cause=$self->agi->get_full_variable('${SIPcause}');
                db_query_exec_("insert into trunks_cdr(number,trunk_id,group_id,dialled,trunk_type,billsec,cost,uniq,sip_cause) 
                        values('$dst',$id,$gid,'$new_number','$trunk_type',$time,$cost,'$unique','$cause')",$con);
		$self->do_cost($con,$time);
                unuse_trunk($self,$con,$prefix,$id,$gid,($time>0),$time,$unique);
                $self->tlog(0,"$prefix result $res time $time");

		if (($config{do_success_hold})&&($time==$success_time)){
			$do=-5;
			$self->tlog(0,"$prefix looks like was disconenct on whitelist");
			$self->agi->exec('ResetCDR','w');
	                $self->set_ip($ip,$agent_name,$rule_name,$rate_value,$dstStripped);
		}
        } else {$self->tlog(0,"$prefix DIAL $res"); #not answered
		my $cause=$self->agi->get_full_variable('${SIPcause}');
		$self->tlog(0,"$prefix sip cause $cause ");
                db_query_exec_("insert into trunks_cdr(number,trunk_id,group_id,dialled,trunk_type,billsec,cost,uniq,sip_cause)
                   values('$dst',$id,$gid,'$new_number','$trunk_type',0,$cost,'$unique','$cause')",$con);
                unuse_trunk($self,$con,$prefix,$id,$gid,0,0,$unique);
                $self->agi->exec('ResetCDR','w');
                $self->set_ip($ip,$agent_name,$rule_name,$rate_value,$dstStripped);
        }
   }#else/dialstatus
   return $do;
 }


 sub do_cost{
    my $self = shift;
    my $con = shift;
    my $time = shift;
    my $cost=$self->{server}{cost};
    my $agent_id=$self->{server}{agent_id};
    if ($cost>0){
	    db_query_exec_("update trunks_agent set credit=credit -(1.00000*$time*$cost)/60  where id=$agent_id",$con);
	    db_commit_($con);
    }
    return ;
 }

 sub child_init_hook {
    my $self = shift;
    $self->{server}{dbi} = Mconnect();
 }


	
 sub black_list{

  my $self=shift;
  my $dst =shift;
  my $black_matched=0;
  my $con=$self->db_check();
  my $prefix=$self->{server}{prefix};
  $self->{server}{blacklist}=0;
  my $black_sql="select distinct  concat(add_prefix,substr('$dst',strip+1)) as  new_number
                                        from trunks_blacklist_rules 
                                        where  whitelist=0  and  '$dst' rlike concat('^',ext_prefix)
                                    limit 1";
  my $black_set=db_query_($black_sql,$con);
  for my $j  (@{$black_set}){
                my ($new_number)=@{$j};
                my $num=substr($dst,-10);
                my $res=db_query_one_("select id from blocklist where  number = ".db_quote($num),$con);
                unless($res){
                }else{
		   $self->{server}{blacklist}=1;
		   $self->{server}{blacklist_before}=$dst;
		   $self->{server}{blacklist_id}=$res;
		   $dst=$new_number;
                   $black_matched=1;
                   $self->tlog(4,"$prefix blacklist new num $dst");
                }
  }
  $self->{server}{whitelist}=0;#  1 if new number was done.
  $self->{server}{whitelist_before}=$dst;
  #white list
  if(!$black_matched){
          my $white_sql="select distinct  concat(add_prefix,substr('$dst',strip+1)) as  new_number
                                        from trunks_blacklist_rules 
                                        where  whitelist=1  and  '$dst' rlike concat('^',ext_prefix)
                                     limit 1";
	  
          my $white_set=db_query_($white_sql,$con);
          for my $j  (@{$white_set}){
                        my ($new_number)=@{$j};
                        my $num=substr($dst,-10);
                        my $res=db_query_one_("select 1 from success_dials  where  number = ".db_quote($num),$con);
                        unless($res){
			   $self->{server}{whitelist}=1;
			   $dst=$new_number;
                           $self->tlog(4,"$prefix whitelist new num $dst");
                        }
          }
  }
  return $dst;
 } 



  sub use_trunk{
	my ($self,$con,$prefix,$id,$gid,$unique)=(@_);
	 $con=$self->db_check();
         db_query_exec_("update  trunks_trunk set c=c+1,in_dial=in_dial+1,last_checked=now() where id=$id",$con);
         db_query_exec_("update  trunks_group set c=c+1,in_dial=in_dial+1,last_checked=now() where id=$gid",$con);
	 db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($id,1,INET_ATON('$server_ip'),$unique)",$con);
	 db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($gid,2,INET_ATON('$server_ip'),$unique)",$con);
	 $self->{server}{trunk_id}=$id;
	 $self->{server}{group_id}=$gid;
	 $self->tlog(4,"$prefix +1 for tr $id / gr $gid");
         db_commit_($con);
  }
  sub unuse_agent{
	my ($self,$con,$prefix,$agent_id,$rule_id,$unique)=@_;
	$con=$self->db_check();
	if($agent_id){
		db_query_one_("select GET_LOCK('trunks_incoming',100)",$con);
                db_query_exec_("update  trunks_agent set in_dial=in_dial-1 where id=$agent_id",$con);
	db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($agent_id,-3,INET_ATON('$server_ip'),$unique)",$con);
		db_commit_($con);
		db_query_one_("select RELEASE_LOCK('trunks_incoming')",$con);
		$self->tlog(4,"$prefix -1 for  agent $agent_id");
		$self->{server}{agent_id}=0;
	};
	if($rule_id){
		db_query_one_("select GET_LOCK('trunks_agent_$agent_id',100)",$con);
		db_query_exec_("update  trunks_agent_rules set in_dial=in_dial-1 where id=$rule_id",$con);
	db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($rule_id,-4,INET_ATON('$server_ip'),$unique)",$con);	    	    db_query_one_("select RELEASE_LOCK('trunks_agent_$agent_id')",$con);
		$self->{server}{rule_id}=0;
		$self->tlog(4,"$prefix -1 for rule $rule_id -$server_ip-");
	}
	db_commit_($con);
  }


  sub unuse_trunk{
        my ($self,$con,$prefix,$id,$gid,$success,$time,$unique)=(@_);
	unless($success) {$success=0;};
	unless($time){$time=0;};
	$con=$self->db_check();
	if($success){$success=", ok=ok+$success";}else {$success="";};
	if($time>0){
		 $time   =", sum=sum+$time";
	} else {
		$time="";
	}
	$con=$self->db_check();
	db_query_exec_("update  trunks_trunk set in_dial=in_dial-1 $success $time where id=$id",$con);
        db_query_exec_("update  trunks_group set in_dial=in_dial-1 $success $time where id=$gid",$con);
	db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($id,-1,INET_ATON('$server_ip'),$unique)",$con);
        db_query_exec_("insert into trunks_counts(id,type,ip,uniqueid) values($gid,-2,INET_ATON('$server_ip'),$unique)",$con);
	$self->{server}{trunk_id}=0;
        $self->{server}{group_id}=0;
	$self->tlog(4,"$prefix -1 for tr $id /gr $gid");
	db_commit_($con);
  }

  sub skip_trunk_used {
	my ($con,$id,$gid)=(@_);
	 my $check=db_query_one_("select  1 from trunks_trunk where $npaused and id=$id",$con);
         unless($check){return 1;}
         $check=db_query_one_("select  1 from trunks_group where $npaused and id=$gid",$con);
         unless($check){return 1;}
	return 0;
  }
  sub  start_active{
	my ($self,$dst,$dst_changed,$trunk_id) = (@_);

	my $cid = $self->input('callerid');
	my $uniqueid=$self->{server}{unique};
	my $con=$self->db_check();
	my $ip=$self->{server}{ip};
	my $exists=db_query_one_("select 1 from trunks_active where uniqueid=".db_quote($uniqueid)." and answer_time>'2001-01-01' limit 1",$con);
	unless($exists){}else{$uniqueid="".(int(substr($uniqueid,1,1))+1).substr($uniqueid,2);}
	my $sql="insert into trunks_active(starttime,agent_id,dst,dst_changed,cid,uniqueid,trunk_id,ip,server_ip) select now(),".db_quote($self->{server}{agent_id}).",".db_quote($dst).','.db_quote($dst_changed).','.db_quote($cid).",".db_quote($uniqueid).",".db_quote($trunk_id).", INET_ATON(".db_quote($ip)."),INET_ATON('$server_ip') from (select 1 as a ) a where (select 1 from trunks_active where uniqueid=".db_quote($uniqueid).") is null";
	db_query_exec_($sql,$con);
	my $sql2="update trunks_active set trunk_id=".db_quote($trunk_id).",dst_changed=".db_quote($dst_changed)."  where uniqueid=".db_quote($uniqueid);
	db_query_exec_($sql2,$con);
	$self->agi->set_variable("__TA_UNIQUE","$uniqueid");
	db_commit_($con);
	
  }
  sub  mark_answer{
	    my $self = shift;
	    my $unique = $self->agi->get_variable('TA_UNIQUE');
	    my $con=$self->db_check();
	    my $prefix=$self->input('uniqueid').' '.$self->input('extension')." " ;
  	    $self->tlog(0,"$prefix update active  answer_time where uniqueid=".db_quote($unique));

	    db_rollback_($con);
	    db_query_exec_("update trunks_active set answer_time=now() where uniqueid=".db_quote($unique),$con);
	    db_commit_($con);
	return 1;
  }
  sub mark_hangup{
	my $self = shift;
            my $unique = $self->agi->get_variable('TA_UNIQUE');
            my $con=$self->db_check();
	    my $prefix=$self->input('uniqueid').' '.$self->input('extension')." " ;
            $self->tlog(0,"$prefix update active  disconnecttime where uniqueid=".db_quote($unique));
            db_rollback_($con);
            db_query_exec_("update trunks_active set disconnecttime =now() where uniqueid=".db_quote($unique),$con);
            db_commit_($con);
        return 1;
  }
  sub reverse_calling{
	my $self = shift;
        my $unique = $self->agi->get_variable('UNIQUEID');
	my $con=$self->db_check();
	my $dst=$self->input('extension');
	my $cid=$self->input('callerid');
	my $prefix=$self->input('uniqueid').' '.$self->input('extension')." " ;
	$self->config_read();
	my $on=$config{reverse_calling};
	$self->tlog(0,"$prefix reverese calling check $dst $cid $on");
	if(($on eq "on")||($on eq "1")){
		$self->agi->answer("");
		my $reverse_calling_lookup=$config{reverse_calling_lookup};
		my $reverse_calling_trunk =$config{reverse_calling_trunk};
		my $reverse_calling_digits=$config{reverse_calling_digits};
		my $comp=substr($cid,-$reverse_calling_digits);
		my $sql="select number,stoptime,uniq from trunks_cdr where substr(number,-$reverse_calling_digits)='$comp' and stoptime > date_sub(now(),interval $reverse_calling_lookup) order by  stoptime desc  limit 1";
		$self->tlog(0,"$prefix $sql");
		my $res=db_query_hash_($sql,$con);
		my $do_dial=0;
		unless($res){}else{# okay,do dial
			unless(db_query_one_("select 1 from trunks_cdr_reverse where substr(number,-$reverse_calling_digits)='$comp' and stoptime > date_sub(now(),interval $reverse_calling_lookup) order by  stoptime desc  limit 1",$con)){
				db_query_exec_("insert into trunks_cdr_reverse(number,stoptime,uniq,reversed) values(".db_quote($res->{'number'}).",".db_quote($res->{'stoptime'}).",".db_quote($res->{'uniq'}).",now())",$con);
				db_commit_($con);
				$do_dial=1;
			}
		}
		if($do_dial){
			my $dial= $reverse_calling_trunk ;
			my $sql="select src from cdr where uniqueid=".db_quote($res->{'uniq'})." and calldate> date_sub(".db_quote($res->{'stoptime'}).",interval 3 hour) and calldate<=".db_quote($res->{'stoptime'})." order by calldate desc limit 1";
			$self->tlog(0,"$prefix $sql");
			my $num=db_query_one_($sql,$con);
			$self->tlog(0,"$prefix reverese calling cid=$num");
			my $last10=substr($num,-10);
			$dial=~s/\$LAST10\$/$last10/;
			$dial.=",20,S(".int(70+rand(200-70)).")o";
			$self->tlog(0,"$prefix reverese calling $dial");
			$self->agi->exec("Dial",$dial);
			my $status=$self->agi->get_variable('DIALSTATUS');
			$self->tlog(0,"$prefix reverese calling status $status");
			if(!($status eq "ANSWERED")){ $do_dial=0;}
			
		}
		if(!($do_dial)){
			my $timeout=int(5+rand(20-5));
			$self->tlog(0,"$prefix reverese calling playback");
			$self->agi->set_variable("TIMEOUT(absolute)",$timeout);
			$self->agi->exec("Background","reversed");
			$self->agi->exec("Wait",$timeout);
		}
	}
	$self->agi->hangup();
  }
  sub  get_g_type {
	my ($self,$gtype)=(@_);
	if ($gtype eq "1"){#BY_COST
                $gtype='cost,RAND()';
        } elsif( $gtype eq 2){  
                $gtype=' RAND() ';
        } elsif( $gtype eq 3 ){
                $gtype=' priority,RAND() ';
	} elsif( $gtype eq 4 ){
		$gtype=' acd desc,RAND()';
	} elsif( $gtype eq 5 ){
                $gtype=' acd desc,priority,RAND()';
	} elsif( $gtype eq 6 ){
                $gtype=' acd desc,cost,RAND()';
        } else {
                return ;
        } 
	return $gtype ;
  }

  sub config_read{
	my $self=shift;
	if(time()- $last_config_read>30){
		my $con=$self->db_check();
		my $res=db_query_("select akey,value from options",$con);
		for my $row (@{$res}){
			my ($akey,$value)=@{$row};
			if(exists $config{$akey}){
				if(!($config{$akey} eq $value)){
					$self->tlog(1,$self->{server}{prefix}."CONFIG changed $akey new value $value");
					$config{$akey}=$value;
				 }
			}else{
				#$self->tlog(1,$self->{server}{prefix}."CONFIG load $akey new value $value");
                                $config{$akey}=$value;
			}
		}
	}
  }
  sub db_check{
	my $self=shift;
	my $dbh=$self->{server}{dbi};
	unless($dbh){
		$self->tlog(4,$self->{server}{prefix}." db connect");
		$dbh=Mconnect();
		
	}
	if(!($dbh->ping())){
		 $dbh=Mconnect();
		$self->tlog(4,$self->{server}{prefix}." db reconnect");
	}
	$self->{server}{dbi} = $dbh;
        return $dbh;
  }
  sub tlog{
   my $self=shift;
   my $level=shift;
   my $error=shift;

   $self->log($level,POSIX::strftime("%Y-%m-%d %H:%M:%S ", localtime).$error);
  }
# sub dispatch_request{
#  my $self = shift;
#  $self->tlog(0,"Dispatch");
# }




END { }
1;


