DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `module` varchar(24) NOT NULL default '',
  `id` varchar(24) NOT NULL default '',
  `level` int(11) NOT NULL default '0',
  `display_text` varchar(255) NOT NULL default '',
  `extended_text` blob NOT NULL,
  `link` varchar(255) NOT NULL default '',
  `reset` tinyint(4) NOT NULL default '0',
  `candelete` tinyint(4) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`module`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('core','AMPDBPASS',500,'Default SQL Password Used','You are using the default SQL password that 
is widely known, you should set a secure password','',0,0,1262213898),('core','AMPMGRPASS',500,'Default Asterisk Manager Password Us
ed','You are using the default Asterisk Manager password that is widely known, you should set a secure password','',0,0,1262213898),
('freepbx','NOEMAIL',600,'No email address for online update checks','You are automatically checking for online updates nightly but 
you have no email address setup to send the results. This can be set on the General Tab. They will continue to show up here.','',0,0
,1262243881),('freepbx','NEWMODS',600,'1 New modules are available','The following new modules are available for download<br>version
upgrade (2.3.0)<br>','',0,1,1202902922),('freepbx','NEWUPDATES',300,'There are 6 modules available for online upgrades','framework 2
.3.1.7 (current: 2.3.1.0)\ninfoservices 1.3.5.3 (current: 1.3.5.1)\ncore 2.3.1.4 (current: 2.3.1.0)\ndashboard 0.3.3.2 (current: 0.3
.3.1)\nrecordings 3.3.5.5 (current: 3.3.5.4)\nmusic 1.5.1.6 (current: 1.5.1.5)\n','',0,0,1262171882),('cron_manager','EXECFAIL',400,
'Cronmanager encountered 1 Errors','The following commands failed with the listed error<br>/var/lib/asterisk/bin/module_admin liston
line (255)','',0,1,1260692401),('retrieve_conf','SYMLINK',400,'symlink from modules failed','retrieve_conf failed to sym link the /e
tc/asterisk/features.conf file from modules','',0,0,1261110205);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL auto_increment,
  `modulename` varchar(50) NOT NULL default '',
  `version` varchar(20) NOT NULL default '',
  `enabled` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'voicemail','2.0.3.4',1),(2,'core','2.3.1.0',1),(3,'featurecodeadmin','1.0.5.3',1),(4,'recordings','
3.3.5.4',1),(5,'framework','2.3.1.0',1),(6,'music','1.5.1.5',1),(7,'infoservices','1.3.5.1',1),(8,'dashboard','0.3.3.1',1),(11,'back
up','2.1.4.9',1);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

DROP TABLE IF EXISTS `ampusers`;
CREATE TABLE `ampusers` (
  `username` varchar(20) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  `extension_low` varchar(20) NOT NULL default '',
  `extension_high` varchar(20) NOT NULL default '',
  `deptname` varchar(20) NOT NULL default '',
  `sections` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ampusers`
--

LOCK TABLES `ampusers` WRITE;
/*!40000 ALTER TABLE `ampusers` DISABLE KEYS */;
INSERT INTO `ampusers` VALUES ('admin','admin','','','','*');
/*!40000 ALTER TABLE `ampusers` ENABLE KEYS */;
UNLOCK TABLES;

