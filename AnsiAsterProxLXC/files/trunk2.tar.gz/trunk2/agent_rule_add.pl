#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
my $id=$cgi->param('id');
unless($id){
	print html_redirect("Agents.pl");
	exit;
}
unless($cgi->param('cost')){
}else{
	my $cost=$cgi->param('cost');
	my $prefix=$cgi->param('prefix');
	my $name=db_quote($cgi->param('name'));
	my $max_count= $cgi->param('max_count');
         $prefix=~s/\s+//g;
         my $pos=index($prefix,'+');
         my $add_prefix='';
         if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
        db_query_exec("insert into trunks_agent_rules(ext_prefix,add_prefix,strip,agent_id,allow,cost,name,max_count)
                         values('$prefix','$add_prefix','$strip',$id,1,$cost,$name,$max_count)");
	db_commit();
	
}
 print html_redirect("agent_edit.pl?id=$id");
