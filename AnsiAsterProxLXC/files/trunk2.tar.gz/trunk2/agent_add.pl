#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
unless($cgi->param('max_count')){
	my $error=$cgi->param("error");
	unless($error){$error='';}else {$error=~s/_/ /g};

my %vars= (  top => util_top('Agents - Add Agent',$who).util_top_menu('Agents'),error=>$error,
	descr => 'Agent',priority=>1,max_count=>5,name=>'Unnamed'
);
	
	my $type=$vars{'type'};
        $vars{'IVR_SCRIPT'}="
        \$(
  function()
  {
	\$('#fips').hide();
	\$('#frules').hide();
  }
 )
";
	print html_header;
	print util_template("templates/agent_edit.tmpl",\%vars);
} else {
	my ($max_count,$descr,$name,$emails,$prefix,$flags,$autopeer)=(
		$cgi->param('max_count'),$cgi->param('descr'),$cgi->param('name'),
		$cgi->param('emails'),$cgi->param('prefix'),$cgi->param('flags'),$cgi->param('autopeer'));
	if (db_query_one("select count(*) from trunks_agent where name=".db_quote($name))>0){
		print html_redirect("agent_add.pl?error=Such_name_exist");
		exit;
	}
	if($autopeer eq "0"){$autopeer='';};
	db_query_exec("insert into trunks_agent (name,descr,emails,max_count,prefix,flags,autopeer) values (
	".db_quote($name).",".db_quote($descr).",".db_quote($emails).",$max_count,'$prefix','$flags','$autopeer')");
	db_commit();
	
	my $id=db_query_one("select id from trunks_agent where name=".db_quote($name)." order by id desc limit 1");

        my $allow=0;
        foreach(split(/\n/,$cgi->param('deny'))){
                my $prefix=$_;
                $prefix=~s/\s+//g;
                my $pos=index($prefix,'+');
                my $add_prefix='';
                if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
                db_query_exec("insert into trunks_agent_rules(ext_prefix,add_prefix,strip,agent_id,allow)
                         values('$prefix','$add_prefix','$strip',$id,$allow)");
        }

	print html_redirect("agent_edit.pl?id=$id");

}
