#!/usr/bin/perl -I .

use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $input= db_query("select login_name,id from users");

for my $i (@{$input}){
   print @{$i}[0]."\n";
	my $input2= db_query("select pagename from user2page where user_id=".@{$i}[1]);
	for my $i2 (@{$input2}){
	  print "    ".@{$i2}[0]."\n";
	}
                
  }

