#!/usr/bin/perl -I .

use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

unless($ARGV[1]){
print "Usage:
 ./create_user.pl user password
"
}else{

my $u=$ARGV[0];
my $p=$ARGV[1];
print "user : $u 
pass: $p
";

db_query_exec("delete from users where login_name='$u'");
db_query_exec("insert into users (login_name,password) select '$u',md5('$u$p')");
db_commit();
}

