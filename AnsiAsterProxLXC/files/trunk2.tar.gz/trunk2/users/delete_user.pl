#!/usr/bin/perl -I .

use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

unless($ARGV[0]){
print "Usage:
 ./delete_user.pl user
"
}else{

my $u=$ARGV[0];
print "user : $u 
";

db_query_exec("delete from users where login_name='$u'");
db_commit();
}

