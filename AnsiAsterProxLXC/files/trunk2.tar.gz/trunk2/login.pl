#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;
use CGI ':standard';
use CGI::Carp qw(fatalsToBrowser);


my $cgi=new CGI;
my $login=$cgi->param('login');

unless($login){
 print html_redirect("index.pl");
 exit;
}else {
 my $password=$cgi->param('password');
 my $res=session_login($login,$password);
 unless($res){
        print html_redirect("index.pl?error=Wrong_username_or_password");
        exit;
 }
 my $location=db_query_one("select pagename from user2page where user_id=".$res->param('uid')." limit 1");
 if($location eq "*"){$location="Trunks.pl";}else{$location.=".pl";}
 if($res){
   print session_cookie($cgi,$res);
   print "<html><body onload='window.location = \"$location\"' >Please wait until you are logged in. IF you see this request for a long time, then probably javascript is not enabled in your browser. This site wil not work until it is enabled.</body></html>";
   exit;
 }
 print html_redirect("index.pl?error=Wrong_username_or_password");
}

