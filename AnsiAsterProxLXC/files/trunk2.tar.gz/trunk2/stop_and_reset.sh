#!/bin/bash
for i in 1 3 
do
 echo "/etc/init.d/asterisk stop;exit "|ssh server$i
 
done;
/etc/init.d/asterisk stop
sleep 3
for i in 1 3 
do
 echo "killall server.pl;killall asterisk;exit "|ssh server$i &

done;
killall server.pl
sleep 3
./reset_calls.sh

/etc/init.d/asterisk start

echo pls press ctr-c after each ok
for i in 1 3
do
 echo "/etc/init.d/asterisk start ;exit "|ssh server$i &

done;
