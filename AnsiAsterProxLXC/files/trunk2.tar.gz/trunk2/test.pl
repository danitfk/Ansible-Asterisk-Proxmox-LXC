#!/usr/bin/perl
print "Content-Type: Text/html\r\n\r\n\r\n";
my $script=$0;
$script=~s/.*trunk2\///;
print "$script";
