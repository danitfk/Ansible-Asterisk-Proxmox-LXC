echo "select (select sum(in_dial) from trunks_agent) as agent,
                 (select sum(in_dial) from trunks_group) as group_c,
                
(select sum(in_dial) from trunks_trunk) as trunk,
(select sum(in_dial) from trunks_agent_rules) as rules
"|mysql asterisk -h mysql -u trunk2 -pmtest

asterisk -rx "core show channels"|grep active
