-- MySQL dump 10.11
--
-- Host: server6    Database: asterisk
-- ------------------------------------------------------
-- Server version	5.0.95-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Haity_2`
--

DROP TABLE IF EXISTS `Haity_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Haity_2` (
  `num` varchar(20) default NULL,
  `dest` varchar(40) default NULL,
  `year` varchar(4) default NULL,
  `minutes` decimal(16,5) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Haity_3`
--

DROP TABLE IF EXISTS `Haity_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Haity_3` (
  `num` varchar(20) default NULL,
  `s` decimal(38,5) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access` (
  `uniqueid` varchar(30) default NULL,
  `ip` varchar(20) default NULL,
  KEY `access_get` (`uniqueid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ampusers`
--

DROP TABLE IF EXISTS `ampusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ampusers` (
  `username` varchar(20) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  `extension_low` varchar(20) NOT NULL default '',
  `extension_high` varchar(20) NOT NULL default '',
  `deptname` varchar(20) NOT NULL default '',
  `sections` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analyse_temp`
--

DROP TABLE IF EXISTS `analyse_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analyse_temp` (
  `a` varchar(10) default NULL,
  KEY `analyze_temp_Get` (`a`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analyze_checked`
--

DROP TABLE IF EXISTS `analyze_checked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analyze_checked` (
  `numbe` varchar(20) default NULL,
  `atdate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analyze_test`
--

DROP TABLE IF EXISTS `analyze_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analyze_test` (
  `rnum` varchar(10) NOT NULL default '',
  `bill` decimal(32,0) default NULL,
  KEY `analyze_test_get` (`rnum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blacklist_option`
--

DROP TABLE IF EXISTS `blacklist_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist_option` (
  `black_prefix` varchar(100) default '1010',
  `white_prefix` varchar(100) default '1010'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocklist`
--

DROP TABLE IF EXISTS `blocklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocklist` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `number` varchar(128) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  KEY `blocklist_get` (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=911136 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocklist22mar18`
--

DROP TABLE IF EXISTS `blocklist22mar18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocklist22mar18` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `number` varchar(128) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  KEY `blocklist_get` (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=566074 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocklist9jan18`
--

DROP TABLE IF EXISTS `blocklist9jan18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocklist9jan18` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `number` varchar(128) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  KEY `blocklist_get` (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=242194 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocklist_1nov`
--

DROP TABLE IF EXISTS `blocklist_1nov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocklist_1nov` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `number` varchar(128) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  KEY `blocklist_get` (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=2233055 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocklist_cid`
--

DROP TABLE IF EXISTS `blocklist_cid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocklist_cid` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `number` varchar(128) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`),
  KEY `blocklist_get` (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr`
--

DROP TABLE IF EXISTS `cdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr` (
  `calldate` datetime NOT NULL default '0000-00-00 00:00:00',
  `clid` varchar(80) NOT NULL default '',
  `src` varchar(80) NOT NULL default '',
  `dst` varchar(80) NOT NULL default '',
  `dcontext` varchar(80) NOT NULL default '',
  `channel` varchar(80) NOT NULL default '',
  `dstchannel` varchar(80) NOT NULL default '',
  `lastapp` varchar(80) NOT NULL default '',
  `lastdata` varchar(80) NOT NULL default '',
  `duration` int(11) NOT NULL default '0',
  `billsec` int(11) NOT NULL default '0',
  `disposition` varchar(45) NOT NULL default '',
  `amaflags` int(11) NOT NULL default '0',
  `accountcode` varchar(20) NOT NULL default '',
  `userfield` varchar(255) NOT NULL default '',
  `uniqueid` varchar(32) NOT NULL default '',
  `ip` varchar(20) default NULL,
  `rate_profile` varchar(100) default NULL,
  `rate_name` varchar(100) default NULL,
  `rate_value` decimal(16,5) default '0.00000',
  `dstStripped` varchar(40) default '',
  `term_cost` decimal(16,5) default NULL,
  KEY `cdr_ge2` (`dst`),
  KEY `cdr_get` (`calldate`),
  KEY `cdr_ge3` (`accountcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr_2012_13`
--

DROP TABLE IF EXISTS `cdr_2012_13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_2012_13` (
  `calldate` datetime NOT NULL default '0000-00-00 00:00:00',
  `clid` varchar(80) NOT NULL default '',
  `src` varchar(80) NOT NULL default '',
  `dst` varchar(80) NOT NULL default '',
  `dcontext` varchar(80) NOT NULL default '',
  `channel` varchar(80) NOT NULL default '',
  `dstchannel` varchar(80) NOT NULL default '',
  `lastapp` varchar(80) NOT NULL default '',
  `lastdata` varchar(80) NOT NULL default '',
  `duration` int(11) NOT NULL default '0',
  `billsec` int(11) NOT NULL default '0',
  `disposition` varchar(45) NOT NULL default '',
  `amaflags` int(11) NOT NULL default '0',
  `accountcode` varchar(20) NOT NULL default '',
  `userfield` varchar(255) NOT NULL default '',
  `uniqueid` varchar(32) NOT NULL default '',
  `ip` varchar(20) default NULL,
  `rate_profile` varchar(100) default NULL,
  `rate_name` varchar(100) default NULL,
  `rate_value` decimal(16,5) default '0.00000',
  `dstStripped` varchar(40) default '',
  `term_cost` decimal(16,5) default NULL,
  KEY `cdr_ge2` (`dst`),
  KEY `cdr_get` (`calldate`),
  KEY `cdr_ge3` (`accountcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr_2013_01_04`
--

DROP TABLE IF EXISTS `cdr_2013_01_04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_2013_01_04` (
  `calldate` datetime NOT NULL default '0000-00-00 00:00:00',
  `clid` varchar(80) NOT NULL default '',
  `src` varchar(80) NOT NULL default '',
  `dst` varchar(80) NOT NULL default '',
  `dcontext` varchar(80) NOT NULL default '',
  `channel` varchar(80) NOT NULL default '',
  `dstchannel` varchar(80) NOT NULL default '',
  `lastapp` varchar(80) NOT NULL default '',
  `lastdata` varchar(80) NOT NULL default '',
  `duration` int(11) NOT NULL default '0',
  `billsec` int(11) NOT NULL default '0',
  `disposition` varchar(45) NOT NULL default '',
  `amaflags` int(11) NOT NULL default '0',
  `accountcode` varchar(20) NOT NULL default '',
  `userfield` varchar(255) NOT NULL default '',
  `uniqueid` varchar(32) NOT NULL default '',
  `ip` varchar(20) default NULL,
  `rate_profile` varchar(100) default NULL,
  `rate_name` varchar(100) default NULL,
  `rate_value` decimal(16,5) default '0.00000',
  `dstStripped` varchar(40) default '',
  `term_cost` decimal(16,5) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr_4apr`
--

DROP TABLE IF EXISTS `cdr_4apr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_4apr` (
  `calldate` datetime NOT NULL default '0000-00-00 00:00:00',
  `clid` varchar(80) NOT NULL default '',
  `src` varchar(80) NOT NULL default '',
  `dst` varchar(80) NOT NULL default '',
  `dcontext` varchar(80) NOT NULL default '',
  `channel` varchar(80) NOT NULL default '',
  `dstchannel` varchar(80) NOT NULL default '',
  `lastapp` varchar(80) NOT NULL default '',
  `lastdata` varchar(80) NOT NULL default '',
  `duration` int(11) NOT NULL default '0',
  `billsec` int(11) NOT NULL default '0',
  `disposition` varchar(45) NOT NULL default '',
  `amaflags` int(11) NOT NULL default '0',
  `accountcode` varchar(20) NOT NULL default '',
  `userfield` varchar(255) NOT NULL default '',
  `uniqueid` varchar(32) NOT NULL default '',
  `ip` varchar(20) default NULL,
  `rate_profile` varchar(100) default NULL,
  `rate_name` varchar(100) default NULL,
  `rate_value` decimal(16,5) default '0.00000',
  `dstStripped` varchar(40) default '',
  `term_cost` decimal(16,5) default NULL,
  KEY `cdr_ge2` (`dst`),
  KEY `cdr_get` (`calldate`),
  KEY `cdr_ge3` (`accountcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr_vj_6nov`
--

DROP TABLE IF EXISTS `cdr_vj_6nov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_vj_6nov` (
  `calldate` datetime NOT NULL default '0000-00-00 00:00:00',
  `clid` varchar(80) NOT NULL default '',
  `src` varchar(80) NOT NULL default '',
  `dst` varchar(80) NOT NULL default '',
  `dcontext` varchar(80) NOT NULL default '',
  `channel` varchar(80) NOT NULL default '',
  `dstchannel` varchar(80) NOT NULL default '',
  `lastapp` varchar(80) NOT NULL default '',
  `lastdata` varchar(80) NOT NULL default '',
  `duration` int(11) NOT NULL default '0',
  `billsec` int(11) NOT NULL default '0',
  `disposition` varchar(45) NOT NULL default '',
  `amaflags` int(11) NOT NULL default '0',
  `accountcode` varchar(20) NOT NULL default '',
  `userfield` varchar(255) NOT NULL default '',
  `uniqueid` varchar(32) NOT NULL default '',
  `ip` varchar(20) default NULL,
  `rate_profile` varchar(100) default NULL,
  `rate_name` varchar(100) default NULL,
  `rate_value` decimal(16,5) default '0.00000',
  `dstStripped` varchar(40) default '',
  `term_cost` decimal(16,5) default NULL,
  KEY `cdr_ge2` (`dst`),
  KEY `cdr_get` (`calldate`),
  KEY `cdr_ge3` (`accountcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL auto_increment,
  `modulename` varchar(50) NOT NULL default '',
  `version` varchar(20) NOT NULL default '',
  `enabled` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `module` varchar(24) NOT NULL default '',
  `id` varchar(24) NOT NULL default '',
  `level` int(11) NOT NULL default '0',
  `display_text` varchar(255) NOT NULL default '',
  `extended_text` blob NOT NULL,
  `link` varchar(255) NOT NULL default '',
  `reset` tinyint(4) NOT NULL default '0',
  `candelete` tinyint(4) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`module`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `akey` varchar(100) default NULL,
  `value` varchar(200) default NULL,
  `description` varchar(300) default NULL,
  `vtype` varchar(3) default 'chr',
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `options_akey` (`akey`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_missed`
--

DROP TABLE IF EXISTS `report_missed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_missed` (
  `number` varchar(200) NOT NULL default '',
  `dialled` varchar(200) NOT NULL default '',
  `stoptime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `billsec` int(11) default '0',
  `cost` decimal(16,5) default NULL,
  `uniq` varchar(32) default NULL,
  `name` varchar(50) default '-',
  `ip` varchar(20) default NULL,
  `agent_id` bigint(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` char(32) NOT NULL,
  `a_session` text NOT NULL,
  `last_updated` timestamp NOT NULL default CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `success_dials`
--

DROP TABLE IF EXISTS `success_dials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `success_dials` (
  `number` varchar(11) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `success_dials19may16`
--

DROP TABLE IF EXISTS `success_dials19may16`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `success_dials19may16` (
  `number` varchar(11) default NULL,
  `added_at` timestamp NOT NULL default CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t1`
--

DROP TABLE IF EXISTS `t1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t1` (
  `id` bigint(20) unsigned NOT NULL default '0',
  `updated` timestamp NOT NULL default '0000-00-00 00:00:00',
  `starttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `answer_time` timestamp NOT NULL default '0000-00-00 00:00:00',
  `agent_id` bigint(20) default NULL,
  `dst` varchar(20) default NULL,
  `dst_changed` varchar(20) default NULL,
  `cid` varchar(20) default NULL,
  `disconnecttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ip` bigint(20) default NULL,
  `server_ip` bigint(20) default NULL,
  `uniqueid` varchar(32) default NULL,
  `trunk_id` bigint(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_active`
--

DROP TABLE IF EXISTS `trunks_active`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_active` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `starttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `answer_time` timestamp NOT NULL default '0000-00-00 00:00:00',
  `agent_id` bigint(20) default NULL,
  `dst` varchar(20) default NULL,
  `dst_changed` varchar(20) default NULL,
  `cid` varchar(20) default NULL,
  `disconnecttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ip` bigint(20) default NULL,
  `server_ip` bigint(20) default NULL,
  `uniqueid` varchar(32) default NULL,
  `trunk_id` bigint(20) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MEMORY AUTO_INCREMENT=993888 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_active_26may`
--

DROP TABLE IF EXISTS `trunks_active_26may`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_active_26may` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `starttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `answer_time` timestamp NOT NULL default '0000-00-00 00:00:00',
  `agent_id` bigint(20) default NULL,
  `dst` varchar(20) default NULL,
  `dst_changed` varchar(20) default NULL,
  `cid` varchar(20) default NULL,
  `disconnecttime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ip` bigint(20) default NULL,
  `server_ip` bigint(20) default NULL,
  `uniqueid` varchar(32) default NULL,
  `trunk_id` bigint(20) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent`
--

DROP TABLE IF EXISTS `trunks_agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `in_dial` int(11) default '0',
  `max_count` int(11) default '10',
  `prefix` varchar(10) default NULL,
  `emails` text,
  `descr` text,
  `paused` tinyint(1) default '0',
  `flags` varchar(20) default NULL,
  `autopeer` varchar(10) default '',
  `prepaid` tinyint(1) default '0',
  `credit` decimal(16,7) default '0.0000000',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent2group`
--

DROP TABLE IF EXISTS `trunks_agent2group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent2group` (
  `agent_id` bigint(20) default NULL,
  `group_id` bigint(20) default NULL,
  KEY `runks_agent2group_get` (`agent_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent_ip`
--

DROP TABLE IF EXISTS `trunks_agent_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent_ip` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `ip` bigint(20) default NULL,
  `agent_id` int(11) default NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=2184 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent_ip_15jun`
--

DROP TABLE IF EXISTS `trunks_agent_ip_15jun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent_ip_15jun` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `ip` bigint(20) default NULL,
  `agent_id` int(11) default NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=1938 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent_ip_2`
--

DROP TABLE IF EXISTS `trunks_agent_ip_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent_ip_2` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `ip` bigint(20) default NULL,
  `agent_id` int(11) default NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=1739 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_agent_rules`
--

DROP TABLE IF EXISTS `trunks_agent_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_agent_rules` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `agent_id` int(11) default NULL,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  `name` text,
  `cost` decimal(16,5) default '0.00000',
  `first` int(11) default '1',
  `interv` int(11) default '1',
  `min` int(11) default '1',
  `in_dial` int(11) default '0',
  `max_count` int(11) default '10',
  `allow` tinyint(1) default '1',
  `rule_type` tinyint(4) default '1',
  `from_n` int(11) default '0',
  `to_n` int(11) default '0',
  `parent` bigint(20) default NULL,
  UNIQUE KEY `id` (`id`),
  KEY `agent_id` (`agent_id`,`ext_prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=4181 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_blacklist_rules`
--

DROP TABLE IF EXISTS `trunks_blacklist_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_blacklist_rules` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  `whitelist` tinyint(1) default '1',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cdr`
--

DROP TABLE IF EXISTS `trunks_cdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cdr` (
  `number` varchar(200) NOT NULL default '',
  `dialled` varchar(200) NOT NULL default '',
  `stoptime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `trunk_id` int(11) default NULL,
  `group_id` int(11) default NULL,
  `trunk_type` varchar(10) default 'SIP',
  `billsec` int(11) default '0',
  `cost` decimal(16,5) default NULL,
  `uniq` varchar(32) default NULL,
  `sip_cause` varchar(30) default NULL,
  KEY `trunks_cdr_get` (`number`,`stoptime`),
  KEY `trunks_cdr_Get_one` (`stoptime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cdr_2017_04_12`
--

DROP TABLE IF EXISTS `trunks_cdr_2017_04_12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cdr_2017_04_12` (
  `number` varchar(200) NOT NULL default '',
  `dialled` varchar(200) NOT NULL default '',
  `stoptime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `trunk_id` int(11) default NULL,
  `group_id` int(11) default NULL,
  `trunk_type` varchar(10) default 'SIP',
  `billsec` int(11) default '0',
  `cost` decimal(16,5) default NULL,
  `uniq` varchar(32) default NULL,
  `sip_cause` varchar(30) default NULL,
  KEY `trunks_cdr_get` (`number`,`stoptime`),
  KEY `trunks_cdr_Get_one` (`stoptime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cdr_old`
--

DROP TABLE IF EXISTS `trunks_cdr_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cdr_old` (
  `number` varchar(200) NOT NULL default '',
  `dialled` varchar(200) NOT NULL default '',
  `stoptime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `trunk_id` int(11) default NULL,
  `group_id` int(11) default NULL,
  `trunk_type` varchar(10) default 'SIP',
  `billsec` int(11) default '0',
  `cost` decimal(16,5) default NULL,
  `uniq` varchar(32) default NULL,
  KEY `trunks_cdr_get` (`number`,`stoptime`),
  KEY `trunks_cdr_Get_one` (`stoptime`)
) ENGINE=MyISAM AUTO_INCREMENT=1000000 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cdr_reverse`
--

DROP TABLE IF EXISTS `trunks_cdr_reverse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cdr_reverse` (
  `stoptime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `number` varchar(32) default NULL,
  `uniq` varchar(32) default NULL,
  `reversed` timestamp NOT NULL default '0000-00-00 00:00:00',
  KEY `trunks_cdr_reverse_get` (`number`,`stoptime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cdr_temp`
--

DROP TABLE IF EXISTS `trunks_cdr_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cdr_temp` (
  `number` varchar(200) NOT NULL default '',
  `dialled` varchar(200) NOT NULL default '',
  `stoptime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `trunk_id` int(11) default NULL,
  `group_id` int(11) default NULL,
  `trunk_type` varchar(10) default 'SIP',
  `billsec` int(11) default '0',
  `cost` decimal(16,5) default NULL,
  `uniq` varchar(32) default NULL,
  KEY `trunks_cdr_get` (`number`,`stoptime`),
  KEY `trunks_cdr_Get_one` (`stoptime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_cid_exemption`
--

DROP TABLE IF EXISTS `trunks_cid_exemption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_cid_exemption` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `cid` varchar(30) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_counts`
--

DROP TABLE IF EXISTS `trunks_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_counts` (
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `id` int(11) default NULL,
  `type` tinyint(4) default NULL,
  `ip` bigint(20) default NULL,
  `uniqueid` decimal(16,5) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_dst_exemption`
--

DROP TABLE IF EXISTS `trunks_dst_exemption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_dst_exemption` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `dst` varchar(30) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `dst` (`dst`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_group`
--

DROP TABLE IF EXISTS `trunks_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_group` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `priority` int(11) default '0',
  `descr` varchar(100) default '',
  `type` int(11) NOT NULL,
  `in_dial` int(11) default '0',
  `max_count` int(11) default '1',
  `paused` tinyint(1) default '0',
  `auto_pause_1` tinyint(1) default '0',
  `auto_pause_2` tinyint(1) default '0',
  `auto_pause_3` tinyint(1) default '0',
  `c` bigint(20) default '0',
  `ok` bigint(20) default '0',
  `sum` bigint(20) default '0',
  `last_checked` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `type_param` varchar(10) default '',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_group15apr18`
--

DROP TABLE IF EXISTS `trunks_group15apr18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_group15apr18` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `priority` int(11) default '0',
  `descr` varchar(100) default '',
  `type` int(11) NOT NULL,
  `in_dial` int(11) default '0',
  `max_count` int(11) default '1',
  `paused` tinyint(1) default '0',
  `auto_pause_1` tinyint(1) default '0',
  `auto_pause_2` tinyint(1) default '0',
  `auto_pause_3` tinyint(1) default '0',
  `c` bigint(20) default '0',
  `ok` bigint(20) default '0',
  `sum` bigint(20) default '0',
  `last_checked` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `type_param` varchar(10) default '',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_group_rules`
--

DROP TABLE IF EXISTS `trunks_group_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_group_rules` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `group_id` int(11) default NULL,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  `allow` tinyint(1) default '1',
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ext_prefix` (`ext_prefix`,`allow`,`group_id`),
  KEY `group_id` (`group_id`,`ext_prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=17888 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_group_rules15apr18`
--

DROP TABLE IF EXISTS `trunks_group_rules15apr18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_group_rules15apr18` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `group_id` int(11) default NULL,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  `allow` tinyint(1) default '1',
  UNIQUE KEY `id` (`id`),
  KEY `group_id` (`group_id`,`ext_prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=13445 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_log`
--

DROP TABLE IF EXISTS `trunks_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_log` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `atime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `log` text,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3497 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_rules`
--

DROP TABLE IF EXISTS `trunks_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_rules` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `trunk_id` int(11) default NULL,
  `ext_prefix` varchar(50) default NULL,
  `add_prefix` varchar(50) NOT NULL default '',
  `strip` tinyint(4) NOT NULL default '0',
  `allow` tinyint(1) default '1',
  UNIQUE KEY `id` (`id`),
  KEY `trunk_id` (`trunk_id`,`ext_prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=3042 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_template`
--

DROP TABLE IF EXISTS `trunks_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_template` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(100) default '',
  `trunk_type` varchar(8) default 'SIP',
  `value` text,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_trunk`
--

DROP TABLE IF EXISTS `trunks_trunk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_trunk` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `cost` decimal(16,5) default '0.00000',
  `name` varchar(50) default '-',
  `descr` varchar(100) default '',
  `ip` varchar(100) default NULL,
  `secret` varchar(20) NOT NULL,
  `template_id` int(11) NOT NULL,
  `in_dial` int(11) default '0',
  `max_count` int(11) default '1',
  `paused` tinyint(1) default '0',
  `auto_pause_1` tinyint(1) default '0',
  `auto_pause_2` tinyint(1) default '0',
  `auto_pause_3` tinyint(1) default '0',
  `c` bigint(20) default '0',
  `ok` bigint(20) default '0',
  `sum` bigint(20) default '0',
  `last_checked` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `trunk_type` varchar(10) default 'SIP',
  `priority` int(11) default '5',
  `add_ip` text,
  `max_call_time` bigint(20) default '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunks_trunk2group`
--

DROP TABLE IF EXISTS `trunks_trunk2group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trunks_trunk2group` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `gid` int(11) default NULL,
  `tid` int(11) default NULL,
  UNIQUE KEY `id` (`id`),
  KEY `gid` (`gid`),
  KEY `tid` (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=634 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user2page`
--

DROP TABLE IF EXISTS `user2page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user2page` (
  `user_id` bigint(20) default NULL,
  `pagename` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `email` varchar(40) default NULL,
  `login_name` varchar(35) default NULL,
  `password` varchar(35) default NULL,
  `user_status` tinyint(4) NOT NULL default '0',
  `firstname` varchar(100) default 'first',
  `lastname` varchar(100) default 'last',
  `active` tinyint(1) default '1',
  `admin_id` bigint(20) default '1',
  `address` varchar(150) default NULL,
  `address2` varchar(150) default NULL,
  `city` varchar(150) default NULL,
  `zipcode` varchar(20) default NULL,
  `VAT` varchar(30) default NULL,
  `language` varchar(3) default NULL,
  `have_users` tinyint(1) default NULL,
  UNIQUE KEY `id` (`id`),
  KEY `mweb_users_get` (`login_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ussd_codes`
--

DROP TABLE IF EXISTS `ussd_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ussd_codes` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `provider` varchar(100) default NULL,
  `cardnum` varchar(100) default NULL,
  `currency` varchar(5) default NULL,
  `value` decimal(16,4) default NULL,
  `ussdmessage` text,
  `chan` int(11) default NULL,
  `sim` int(11) default NULL,
  `phonenum` varchar(40) default NULL,
  `ussdstart` varchar(100) default NULL,
  `ussdend` varchar(100) default NULL,
  `state` varchar(100) NOT NULL default 'free',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-22 18:31:39
