killall safe_server.sh
./start_safe_server.sh
