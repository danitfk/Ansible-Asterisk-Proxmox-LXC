#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who=$ses->param("login_name");

my $pauses='';
unless($cgi->param('cost')){
my %vars= (  top => util_top('Trunks - Add Trunk',$who).util_top_menu('Trunks'),
	name => 'unnamed',cost=>1,priority=>5,max_count=>1,descr=>'',secret=>'0000',ip=>'127.0.0.1',allow=>"[0-9]",max_call_time=>0,
	templates=>html_select(db_query("select concat(trunk_type,'/',name),id from trunks_template")," name ='template_id' id='template_id' ")
);
	
	print html_header;
	print util_template("templates/trunk_edit.tmpl",\%vars);
} else {
	my ($name,$cost,$max_count,$descr,$secret,$ip,$template_id,$priority,$add_ip,$max_call_time)=(
	$cgi->param('name'),$cgi->param('cost'),
	$cgi->param('max_count'),$cgi->param('descr'),$cgi->param('secret'),$cgi->param('ip'),$cgi->param('template_id'),
	$cgi->param('priority'),$cgi->param('add_ip'),$cgi->param('max_call_time'));
	my $trunk_type=db_query_one("select trunk_type from trunks_template where id=$template_id");
	db_query_exec("insert into trunks_trunk (name,cost,max_count,descr,secret,ip,template_id,trunk_type,priority,add_ip,max_call_time)
	 values (
	".db_quote($name).",$cost,$max_count,".db_quote($descr).",".db_quote($secret).",'$ip',$template_id,'$trunk_type',$priority,'$add_ip',$max_call_time)");
	db_commit();
	
	my $id=db_query_one("select id from trunks_trunk where name=".db_quote($name)." order by id desc limit 1");
	foreach(("allow","deny")){
                my $pallow=$_;
                my $allow=0;
                if($pallow eq "allow"){$allow=1;};
        foreach(split(/\n/,$cgi->param($pallow))){
                my $prefix=$_;
                $prefix=~s/\s+//g;
                my $pos=index($prefix,'+');
                my $add_prefix='';
                if ($pos>0){
                 $add_prefix=substr($prefix,0,$pos);
                 $prefix=substr($prefix,$pos+1);
                }
                my $strip=index($prefix,'|');
                if ($strip <=0){$strip=0;}
                $prefix=~s/\|//;
                db_query_exec("insert into trunks_rules(ext_prefix,add_prefix,strip,trunk_id,allow)
                         values('$prefix','$add_prefix','$strip',$id,$allow)");
        }
        }#alow,deny

	db_commit();
	print html_redirect("Trunks.pl");

}
