#!/usr/bin/perl -I .
use strict;
use warnings;

use mlib::db;
use mlib::html;
use mlib::utils;
use mlib::session;

use mlib::calls;
use CGI;
use DBI;

my $cgi=new CGI;
#check session
my $ses=db_session();
if(!ses_allow($ses,$0)){exit;}


my ($a);
my $channels;
#my $params=$ses->dataref();
#while ( my ($key, $value) = each(%$params) ) {
#        $channels.= "$key => $value\n";
#}
my $uid=0;
my $who='User '.$ses->param("login_name");

db_query_exec("update trunks_trunk set auto_pause_1 =0 where auto_pause_1 is null");
db_query_exec("update trunks_trunk set auto_pause_2 =0 where auto_pause_2 is null");
db_query_exec("update trunks_trunk set auto_pause_3 =0 where auto_pause_3 is null");

db_commit();

#start block
my $mname="";
print html_header;
my $broken="";
my $pauses='';

my %vars= (  top => util_top('Agents',$who).util_top_menu('Agents'),tab=>html_table(db_query("select 
   concat('<a href=\"agent_edit.pl?id=',id,'\" >E</a> <a href=\"agent_pause.pl?id=',id,'\" >',case when paused then 'U' else 'P' end ,'</a>') as action,
	name,descr,convert(credit,DECIMAL(16,2)) ,concat(in_dial,'/',max_count),
	case when paused then 'Paused' else '' end
  from trunks_agent order by name" )
 )
);

print util_template("templates/Agents.tmpl",\%vars);
